#!/usr/bin/env python3

from gecommon import *

asock = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)
asock.settimeout(10)
a_addr = ('localhost', 29999)
bufferSize  = 1024

def get_work():
    asock.sendto(done_work.encode(), a_addr)
    msg, addr = asock.recvfrom(bufferSize)
    content = msg.decode()
    if content == 'RETRY':
        raise Exception('RETRY')
    return content
    

def push_work(level):
    body = {'levels':level, 'status':'downloading12', 'worker':worker_id, 'level':len(level)}
    es.index(index='map_work', doc_type='work', id=level, body=body, refresh=True)         
    
def work_done(level):
    es.update(index='map_work', doc_type='work', id=level, body={
                        'doc':{'status':'downloaded'}}, refresh=True)    
    
#import gedecode

# os.chdir('/root/py/m2')
# os.chdir('/root/bt/new/map')



g_stop = False
def inorder_download(httpclient, node, path_name, prefix, tree_path):
    global g_stop
    if os.path.exists('stop'): 
        g_stop = True
        return
    flags = node.flags
    if flags & 0x40: ## have image
        fn = '%s%s.%d.JFIF'%(prefix, tree_path, node.image_version)
        fn = os.path.join(path_name, fn)
        if not os.path.exists(fn):
            url = 'https://kh.google.com/flatfile?f1-%s%s-i.%s'%(prefix, tree_path, node.image_version)
            code, img = httpclient.get(url)
            img = decrypt(img)
            assert img[6:10] == b'JFIF'
            write_file(fn, img)
    if flags & 0x80: ## have terrain info
        fn = '%s%s.%d.t'%(prefix, tree_path, node.image_version)
        fn = os.path.join(path_name, fn)
        if not os.path.exists(fn):
            url = 'https://kh.google.com/flatfile?f1c-%s%s-t.%s'%(prefix, tree_path, node.terrain_version)
            code, tr = httpclient.get(url)
            tr = decrypt(tr)
            assert struct.unpack('i', tr[4:8])[0] == len(zlib.decompress(tr[8:]))
            write_file(fn, tr)
#     if flags & 0x10: ## have subtree
#         assert len(tree_path) == 4
# #         print('####################################')
#         if len(prefix) == 16:
#             download_q2_2(httpclient, prefix+tree_path, node.q_version)
#         else:
#             pass
# #             push_work(prefix+tree_path)
    for i in range(4):
        subnode = node._subnodes[i]
        if subnode:
            inorder_download(httpclient, subnode, path_name, prefix, '%s%d'%(tree_path,i))

def download_q2_2(httpclient, levels, ver=876):
    p = levels_2_path(levels)
    if not os.path.exists(p):
        pathlib.Path(p).mkdir(parents=True, exist_ok=True)
    fn = '%s.%d.q' % (levels, ver)
    fn = os.path.join(p, fn)
    if os.path.exists(fn+'.404'):
        return
    if not os.path.exists(fn):
        code, qp = httpclient.get('https://kh.google.com/flatfile?q2-%s-q.%d'%(levels,ver))
        if code == 404:
            open(fn+'.404', 'wb')
            return
        qp = decrypt(qp)
        assert struct.unpack('i', qp[4:8])[0] == len(zlib.decompress(qp[8:]))
#         open(fn_tmp, 'wb').write(qp)
        write_file(fn, qp)
    else:
        qp = open(fn, 'rb').read()
    qp = zlib.decompress(qp[8:])
    header, qtp = decode_qtpacket(qp)
    inorder_download(httpclient, qtp, p, levels, '')
    
hc = HttpClient() ## global HttpClient
    
def download_q2(levels, ver=876):
    try:
#         print('hello')
#         hc = HttpClient()
        download_q2_2(hc, levels, ver)
        print('%s Done'%levels)
    except:
        traceback.print_exc()
        
done_work = ''
current_work = ''
        
def go():
    global g_stop
    global done_work
    global current_work
    while True:
        try:
            if os.path.exists('stop'): 
                g_stop = True
                break
            if not current_work:
                level = get_work()
            else:
                level = current_work
            if not level:
                print('Nothing to to ...')
                return
            if level == 'WAIT':
                time.sleep(2)
                continue
#             print('%s Downloading ...'%level)
            logging.info('%s Downloading ...'%level)
            done_work = ''
            current_work = level
            download_q2_2(hc, level, 876)
            done_work = level
            current_work = ''
    #             archive_level(level)
#             work_done(level)
    #             print('%s Done'%level)
            logging.info('%s Done'%level)
        except:
            traceback.print_exc()
            t = 5*random.randint(0,255)/255
            time.sleep(t)

go()

if not g_stop:
    time.sleep(20)

