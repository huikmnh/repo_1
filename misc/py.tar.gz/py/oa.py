#!/usr/bin/env python3

import base64

from Crypto.Cipher import DES

def my_encrypt(raw):
    cipher = DES.new('kedacom0', DES.MODE_ECB)
    return cipher.encrypt(raw)

def my_decrypt(raw):
    cipher = DES.new('kedacom0', DES.MODE_ECB)
    return cipher.decrypt(raw)

import requests
import random
import base64

Headers = {
'Content-Type':     'application/x-www-form-urlencoded',
'User-Agent':       'Dalvik/2.1.0 (Linux; U; Android 10; MI 8 SE MIUI/V11.0.2.0.QEBCNXM)',
'Connection':       'Keep-Alive',
'Accept-Encoding':  'gzip',
}

session = 'D74F59EF-06EE-4319-AA27-77E9C37E9624'

# body_raw = b'''devId=8F1E534A566273B5&VER=3.46&OS=ANDROID&method=SubAtten&params=z8fivYD%2BV6EzonTIcuXgSpk2oq1FZm7O5EBtL7wE4FCCHtmddzS%2B6big8dpc+Un%2BjVN%2F8SLddhgDTJvME18VImRatvMvZmf9%2BBMu6wdJ1VGwUTbGiarCcEg8a+5fbLBWYiX6xF4uMyP3hDECBLrdj%2BDw9wtRPUjgmu%2BzZ1j4laAd5hml7ST%2FGJ+IU7rA60Od8tW4NhdaRW20LZiYzeAZCerDXaoX3EulUIAmL%2BWOhtMMS5kcNs8+z%2F3Myx6ZX3%2BLlCIi2Mg3ZuEHw954StYKlvxXDGFKmQHnzdi%2FPjoc8OwpUp7w+j%2B1Q80Y5AzmtV8VnDkg8X30Wk7slAyF34tc%2F7f%2BGSaw8WKVGkO0NXRg4iIys+wqZUx2oixEsT2iRda8guS0djptZjcfyaAsEOHQ2%2BZtZmXX%2BNJqE9N6kqIXF4+0SbfpekEBQqkkwRhvx9UKBse5DNFM6bNSl9Cqjkxar5TbNyv4LFMf0Vhb0ef+sfBplc44uwABxbKKJtNauW%2BZFARk1lcpEcyA5E2Kcp1anE2H0Cda3n9N8A9j+MkG6qioPhnaSRRLs5dbxWedTkceWSK7%2FPmz4IKlT2a9kt0u3fk0UxztiPg%3D%3D&corpCode=1001&account=wangwei_ga%40kedacom.com&vkey=72728685-723D-433C-B7D6-A8951ECD7364'''
body_temp = '''devId=8F1E534A566273B5&VER=3.50&OS=ANDROID&method=SubAtten&params={}&corpCode=1001&account=wangwei_ga%%40kedacom.com&vkey=%s''' % session
temp = '{"deptName":"事业部群/应急管理事业部/应急管理事业部系统部/技术预研组","detailAddress":"上海市徐汇区虹梅路2007号-3号楼","empCode":"KD006330","mac":"8F1E534A566273B5","os":"ANDROID","phoneDesc":"MI 8 SE29","picPath":"","remark":"","ruleId":10000016081487,"signAddress":"上海远中产业园-2号楼","signLatitude":"%s","signLongitude":"%s","signType":0,"class":".attendance.AttendanceSubCond"}\x02\x02'
temp = '{"deptName":"创新资源中心/创新资源中心软件技术中心/软件技术中心人工智能算法部","detailAddress":"上海市上海市徐汇区宜山路1398号","empCode":"KD006330","mac":"8F1E534A566273B5","os":"ANDROID","phoneDesc":"MI 8 SE29","picPath":"","remark":"","ruleId":10000007060000,"signAddress":"上海远中产业园-2号楼","signLatitude":"%s","signLongitude":"%s","signType":0,"class":".attendance.AttendanceSubCond"}\x03\x03\x03'

def random_int():
    a = random.randint(1,999)
    if a%10 == 0:
        a += 1
    return a

def random_pos():
    x = 121.4 + random_int()/1000000
    y = 31.177 + random_int()/1000000
    return '%.6f'%y, '%.6f'%x

def post_1():
    resp = requests.request('POST', 'http://iapp.kedacom.com:8081/interface/mobile.do?action=ehr', headers=Headers, data=body_raw)
    return resp.text
    pass

def my_base64_encode(raw):
    ret = b''
    n = 0
    for i in base64.encodebytes(raw):
        if i == b'\n'[0]:
            continue
        ret += bytes([i])
        n += 1
        if n % 64 == 0:
            ret += b' '
    return ret.decode('utf-8')
    

def post_2():
    param = my_base64_encode(my_encrypt((temp % random_pos()).encode('utf-8')))
    body = body_temp.format(requests.utils.quote(param)).encode('utf-8')
    resp = requests.request('POST', 'http://iapp.kedacom.com:8081/interface/mobile.do?action=ehr', headers=Headers, data=body)
    return resp.text
    pass

print(post_2())