#!/usr/bin/env python3

import json, http.client, struct, os, sys

def login(mac):
    conn = http.client.HTTPSConnection("web.hanyou.com")
    conn.request("GET", "/m/login_t.do?mac="+mac+"&state=%E4%B8%8A%E6%B5%B7&city=%E4%B8%8A%E6%B5%B7&lineid=100000")
    content = conn.getresponse().read()
    content = json.loads(content.decode('utf-8'))
    return content

if len(sys.argv) > 1:
    mac = sys.argv[1]
    
info = login(mac)
print('userId\t', info['userId'])
print('score\t', info['score'])
print('medals\t', info['medals'])
