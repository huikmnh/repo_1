
############################################################
## game connection part


class GameConnection():
    def get_message(self, timeout=None):
        return None
    def send_message(self, msg):
        pass
    def close(self):
        pass

import socket
from scapy.all import *
class TS():
    def __init__(self, pkt):
        self.init = True
        if 'Raw' in pkt:
#             self.data = pkt[Raw].load
            self.data = b''
            self.nseq = pkt[TCP].seq + len(self.data)
        else:
            self.data = b''
            if pkt[TCP].flags & 2 == 2:
                self.nseq = pkt[TCP].seq  + 1
    def add_packet(self, pkt):
        ret = []
        if pkt[TCP].seq != self.nseq:
#             print(pkt[TCP].seq, self.nseq)
#             print('Oops')
            return ret
        if 'Raw' in pkt:
            self.data += pkt[Raw].load
            self.nseq = pkt[TCP].seq + len(pkt[Raw].load)
            if self.init:
                head = self.data.find(b'\r\n\r\n')
                if head > 0:
                    begin = head+4
                    self.init = False
                    self.c = begin
            if not self.init:
                for i in range(5):
                    found_frame = False
                    if len(self.data) - self.c >= 2:
                        ws_op, ws_len = struct.unpack('BB', self.data[self.c:self.c+2])
                        ll = 0
                        mm = 0
                        mask_flag = ws_len & 0x80
                        ws_len = ws_len & 0x7f
                        if mask_flag > 0: mm = 4
                        if ws_len == 126:
                            ll = 2
                            if len(self.data) - self.c >= 2+ll+4:
                                ws_len = struct.unpack('>H', self.data[self.c+2:self.c+4])[0]
                        if len(self.data) - self.c >= 2+ll+mm+ws_len:
                            payload = self.data[self.c+2+ll+mm:self.c+2+ll+mm+ws_len]
                            if mask_flag == 0:
                                masks = b'\x00\x00\x00\x00'
                            else:
                                masks = self.data[self.c+2+ll:self.c+2+ll+4]
                            if mask_flag: 
                                payload = unmask_payload(payload, masks)
                            if ws_op == 0x82:
                                ret.append((payload, mask_flag))
                            found_frame = True
                            self.c += 2+ll+mm+ws_len
                            self.data = self.data[self.c:]
                            self.c = 0
                    if not found_frame:
                        break
        else:
            if pkt[TCP].flags & 3 : # SYN or FIN
                self.nseq = pkt[TCP].seq  + 1
        return ret

class PcapGameConnection(GameConnection):
    def __init__(self, filename=None, live=False):
        self.msgs = []
        self.to = None
        if filename:
            self.pkts = []
            def dp(pkt):
                self.pkts.append(pkt)
            sniff(prn=dp, offline=filename)
#             print(self.pkts)
            self.pkts = iter(self.pkts)
        if live:
            self.sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sk.bind(('0.0.0.0', 8989))
        def message_gen():
            ss = {}
#             n = 0
            while True:
#                 print('n -> ', n)
                if self.msgs:
                    yield self.msgs[0]
                    del self.msgs[0]
                else:
                    if filename and not live:
                        p = next(self.pkts)
                    if live:
                        try:
                            self.sk.settimeout(self.to)
                            data, addr = self.sk.recvfrom(8192)
                        except socket.timeout:
                            yield None, 0
                        except:
                            self.sk = None
                        p = Ether(data)
                    if (p[TCP].sport, p[TCP].dport) not in ss:
                        s = TS(p)
                        ss[(p[TCP].sport, p[TCP].dport)] = s
                    else:
                        s = ss[(p[TCP].sport, p[TCP].dport)]
                        ms = s.add_packet(p)
                        self.msgs += ms
#                 n += 1
        self.msg_gen = message_gen()
    def deal_pkt(self):
        pass
    def get_message(self, timeout=None):
        self.to = timeout
        while True:
            msg, mask = next(self.msg_gen)
            if msg == None:    ## when live mode and no notify
                return None
            if not timeout:
                if mask == 0:
                    return msg
                else:
                    if type(PKT.decode(msg)) == HEAT_BEAT: continue
                    if msg != self.send_buf:
                        cprint('################### send payload mismatch ######################', 'yellow')
                        print(msg)
                        print(self.send_buf)
                        print(PKT.decode(msg))
                        print(PKT.decode(self.send_buf))
                        print('----------------------------------------------------------------')
                    else:
                        print('################### send payload matched ######################')
                        print(PKT.decode(self.send_buf))
                        print('***************************************************************')
            else:
                if type(PKT.decode(msg)) == SUB_S_OPERATE_NOTIFY:
                    return msg
                else:
                    self.msgs.insert(0, msg)
                    return None
                    
    def send_message(self, buf):
        if type(PKT.decode(buf)) == HEAT_BEAT: return
        self.send_buf = buf

from websocket import create_connection,WebSocketTimeoutException
import threading

class WSGameConnection(GameConnection):
    def __init__(self, game_port=17301):
        self.ws = create_connection("ws://73.hanyou.com:%s/"%game_port)
        self.lock = threading.Lock()
    def send_message(self, buf):
        self.lock.acquire()
        try:
            self.ws.send(buf)
        finally:
            self.lock.release()
    def get_message(self, timeout=None):
        self.lock.acquire()
        try:
            self.ws.settimeout(timeout)
            return self.ws.recv()
        except WebSocketTimeoutException:
            return None
        finally:
            self.lock.release()
    def close(self):
        self.ws.close()
##########################################################################
## The AI Part

weights = [10, 20, 30, 40, 50, 40, 30, 20, 10, 
          10, 20, 30, 40, 50, 40, 30, 20, 10, 
          10, 20, 30, 40, 50, 40, 30, 20, 10, 
          5, 5, 5, 5, 5, 5, 5, 5, 5]

def discard_tile(hand, dead):
    rs = calculate_outs(hand, dead)
    rs.sort(key=lambda x:(-x['tiles_count'], weights[x['discard']]))
    return rs[0]
#     return rs[0]['discard']

def give_me_tile(candi, hand, dead):
    ret = []
    for i in candi:
        if should_op_tile(hand, dead, i):
            ret.append(i)
    return ret

def should_op_tile(hand_orig, dead_orig, tile):
    hand = list(hand_orig)
    hand[33] += 1
    rs = calculate_outs(hand, dead_orig)
    if not rs:
        return None
#     rs.sort(key=lambda x:(-x['tiles_count'], weights[x['discard']]))
    best_opt = None
    for opt in rs:
        if opt['discard'] == 33:
            best_opt = opt
    if not best_opt: return None
    ret = None
#     print(best_opt)
    if hand[tile] >1 :
        hand = list(hand_orig)
        dead = list(dead_orig)
        hand[tile] -= 2
        dead[tile] += 3
        rs = calculate_outs(hand, dead)
        opt = rs[0]
#         print(opt)
        if opt['shanten'] < best_opt['shanten'] or opt['tiles_count'] > best_opt['tiles_count']:
            best_opt = opt
            ret = (tile, tile)
    if hand[tile+1] > 0 and hand[tile+2] > 0 and tile < 27 and (tile)//9 == (tile+2)//9:
        hand = list(hand_orig)
        dead = list(dead_orig)
        hand[tile+1] -= 1
        hand[tile+2] -= 1
        dead[tile] += 1
        dead[tile+1] += 1
        dead[tile+2] += 1
        rs = calculate_outs(hand, dead)
        opt = rs[0]
#         print(opt)
        if opt['shanten'] < best_opt['shanten'] or opt['tiles_count'] > best_opt['tiles_count']:
            best_opt = opt
            ret = (tile+1, tile+2)
    if hand[tile+1] > 0 and hand[tile-1] > 0 and tile < 27 and (tile+1)//9 == (tile-1)//9:
        hand = list(hand_orig)
        dead = list(dead_orig)
        hand[tile+1] -= 1
        hand[tile-1] -= 1
        dead[tile] += 1
        dead[tile+1] += 1
        dead[tile-1] += 1
        rs = calculate_outs(hand, dead)
        opt = rs[0]
#         print(opt)
        if opt['shanten'] < best_opt['shanten'] or opt['tiles_count'] > best_opt['tiles_count']:
            best_opt = opt
            ret = (tile-1, tile+1)
    if hand[tile-1] > 0 and hand[tile-2] > 0 and tile < 27 and (tile)//9 == (tile-2)//9:
        hand = list(hand_orig)
        dead = list(dead_orig)
        hand[tile-1] -= 1
        hand[tile-2] -= 1
        dead[tile] += 1
        dead[tile-1] += 1
        dead[tile-2] += 1
        rs = calculate_outs(hand, dead)
        opt = rs[0]
#         print(opt)
        if opt['shanten'] < best_opt['shanten'] or opt['tiles_count'] > best_opt['tiles_count']:
            best_opt = opt
            ret = (tile-2, tile-1)
    return ret
    

def calculate_outs(hand, dead):
    """
    hand: 34 array
    dead: 34 array
    """
    if sum(hand) == 1:
        t = 0
        for i in range(34):
            if hand[i]:
                t = i; break
        return [{'shanten':0, 'waiting':[1], 'tiles_count':99, 'discard':t}]
    meld_num = 4 - sum(hand)//3
    results = []
#     print(hand, dead)
    hand_bak = list(hand)
    s_in = shanten(hand, meld_num)
#     print('--> s_in ', s_in)
    should_run_2 = False
    for k in (1, 2):
        for candi in range(34):
            if not hand[candi]:
                continue
            hand[candi] -= 1
            hand[33] += 1
            s = shanten(hand, meld_num)
            hand[33] -= 1
            if s > s_in and not should_run_2:
                hand[candi] += 1
                continue

            waiting = []
            tiles_count = 0
            for j in range(0, 34):
                if candi == j or hand[j] == 4:
                    continue
                hand[j] += 1
                if shanten(hand, meld_num) < s:
                    waiting.append(j)
    #                 print((4 - hand_bak[j] - dead[j]), TilesConverter.to_one_line_string([j*4]), hand_bak[j], dead[j], j)
                    tiles_count += (4 - hand_bak[j] - dead[j])
                hand[j] -= 1
            hand[candi] += 1

            if waiting:
                discard_opt = {'shanten':s, 'waiting':waiting, 'tiles_count':tiles_count, 'discard':candi}
                results.append(discard_opt)
        results.sort(key=lambda x:(x['shanten'], -x['tiles_count'], weights[x['discard']]))
        if results:
            if should_run_2:
                s = set(results[0]['waiting'])
                for i in results:
                    s = s.intersection(i['waiting'])
                if s:
                    t = s.pop()
                    if hand[t]: 
#                         for i in results:
#                             print(i)
                        return [{'shanten':1, 'waiting':[], 'tiles_count':99, 'discard':t}]
            return results
        else:
            should_run_2 = True
    if not results: ## in case =======> my hand:  9条|9条|9条|9条|1万|2万|3万|混|
        for i in range(34):
            if hand[i] == 4:
                return [{'shanten':1, 'waiting':[], 'tiles_count':99, 'discard':i}]
    return results



##########################################################################
## The Game Logic Part

import json, http.client, struct, os, time
from codes import *

def login(mac, port=17301):
    conn = http.client.HTTPSConnection("web.hanyou.com")
    conn.request("GET", "/m/login_t.do?mac="+mac+"&state=%E4%B8%8A%E6%B5%B7&city=%E4%B8%8A%E6%B5%B7&lineid=100000")
    content = conn.getresponse().read()
    content = json.loads(content.decode('utf-8'))
    headers = {"Cookie":"JSESSIONID=%s"%content['sessionid'],"session_id":"%s"%content['sessionid'],
              "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 5.1.1; SM-N9005 Build/NJH47F)"}
    if content['score'] < 500:
        conn.request("POST", "/reloadGameMoney.do", '', headers)
        sync_ret = conn.getresponse().read()
        sync_ret = json.loads(sync_ret.decode('utf-8'))
        cprint(sync_ret, 'yellow')
    conn = http.client.HTTPConnection("web.hanyou.com")
    print('$$$$$$$$--> ', port)
    conn.request("POST", "/login/synconline.do?gid=73&sid=%s"%port, '', headers)
    sync_ret = conn.getresponse().read()
    sync_ret = json.loads(sync_ret.decode('utf-8'))
    return content

def prize(mac, count=100, take_all=False):
    para_map = {100:295, 500:235, 1000:91, 5000:445, 10000:92}
    conn = http.client.HTTPSConnection("web.hanyou.com")
    conn.request("GET", "/m/login_t.do?mac="+mac+"&state=%E4%B8%8A%E6%B5%B7&city=%E4%B8%8A%E6%B5%B7&lineid=100000")
    content = conn.getresponse().read()
    content = json.loads(content.decode('utf-8'))
    medals = content['medals']
    if take_all:
        count = medals
    ids = []
    keys = list(para_map.keys())
    keys.sort(reverse=True)
    for i in keys:
        while count >= i:
            ids.append(para_map[i])
            count -= i
    headers = {"Cookie":"JSESSIONID=%s"%content['sessionid'],"session_id":"%s"%content['sessionid'],
              "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 5.1.1; SM-N9005 Build/NJH47F)"}
    for i in ids:
        conn.request("POST", "/shop/exchange.do?orders.type=1&orders.prizeId=%d&orders.mobile=&orders.exchangeMode=0&orders.address=&orders.userName=&orders.preAddress=&orders.jdProvinces=0&orders.jdCity=0&orders.jdCounty=0&orders.jdTown=0"%i, '', headers)
        sync_ret = conn.getresponse().read()
        sync_ret = json.loads(sync_ret.decode('utf-8'))
        print('got some money')
        time.sleep(1)
    #print(sync_ret)

# login('ffffffff-b319-4c6f-ffff-ffffa7b1fa34')


from termcolor import colored, cprint
import time, random
class VGame():
    def __init__(self, isus=False, me_richer=False, me_id=None, enemy_id=None, target=7):
        self.hand = []
        self.me_out_list = []
        self.enemy_out_list = []
        self.double = 0
        self.isus = isus
        self.me_richer = me_richer
        self.enemy_id = enemy_id
        self.me_id = me_id
        self.can_hu = False
        self.target = target
        if isus:
            self.pattrs = ['underline']
        else:
            self.pattrs = []
    def me_out(self, tile):
        if tile >= 0x35 and tile <= 0x37: self.double += 1
        self.me_out_list.append(tile)
        self.hand.remove(tile)
        print('==========> We out ', CARDS[tile])
        self.print_myhand()
    def me_worst_tile(self):
        if not self.isus:   ## emulate human thinking
            time.sleep(random.random()*2)
        t = None
        aux = ''
        if self.me_richer:
            l = enemy_wanted_list(self.enemy_id)
            print ('%%%%%%%%%%%-> ', l)
            if not l:
                l = [99]
            if self.fan() < self.target:
                for i in self.hand:
                    if i >= 0x35 and i <=0x37:  # double
                        t =i; break
            if not t: ## no double found
                if l[-1] ==0:   ## enemy can win but don't want to, for there is too few double
                    for i in self.hand:
                        if i not in l:
                            t = i; break
                else:
                    for i in self.hand:
                        if i in l:
                            t = i; break
            if not t:
                for i in self.hand:
                    if i < 0x35:
                        t = i; break
        else:
            ####
            aux = ''
            if 0x35 in self.hand:
                t = 0x35
            if 0x36 in self.hand:
                t = 0x36
            if 0x37 in self.hand:
                t = 0x37
            if not t:
                self.print_myhand()
                #print(list_to_34(self.hand))
                h = list_to_34(self.hand)
                d = list_to_34(self.me_out_list+self.enemy_out_list)
                do = discard_tile(h, d)
                if do['shanten'] <= 1:
                    wants = do['waiting']
                else:
                    wants = give_me_tile(do['waiting'], h, d)
                if self.isus:
                    rw = [tile_from_34[i] for i in wants]
                    if do['shanten'] <= 1 and not self.should_hu():
                        rw.append(0)
                    print('%%%%%%%%%%%%%-> ', rw)
                    redis.set(self.me_id, rw)
                t = tile_from_34[do['discard']]
                w = '|'.join([CARDS[tile_from_34[i]] for i in do['waiting']])
                w2 = '|'.join([CARDS[tile_from_34[i]] for i in wants])
                aux = '    shanten[%d]  waiting[%s]  desperate[%s]' % (do['shanten'], w, w2)
        cprint('##############=============> We suggest %s times[%d] %s' % (CARDS[t], 2**self.double, aux), 'green', attrs=self.pattrs)
        return t
    def enemy_out(self, tile):
        if tile >= 0x35 and tile <= 0x37: self.double += 1
        self.enemy_out_list.append(tile)
        print('==========> They out ', CARDS[tile])
    def me_init_hand(self, tiles):
        self.hand = tiles
    def me_draw_tile(self, tile):
        self.hand.append(tile)
        print('==========> We draw ', CARDS[tile])
    def operate_tile(self, tile, mask):
        if self.me_richer:
            return 0
        opt = should_op_tile(list_to_34(self.hand), list_to_34(self.me_out_list+self.enemy_out_list), tile_to_34[tile])
        if opt:
            t1, t2 = [tile_from_34[i] for i in opt]
            rs = [t1, t2, tile]
            rs.sort()
            rs = [CARDS[i] for i in rs]
            cprint('##############=============> We suggest '+ ''.join(rs), 'green', attrs=self.pattrs)
            d = tile - t1
            if d == 0:
                return WIK_PENG
            elif d == -1:
                return WIK_LEFT
            elif d == 1:
                return WIK_CENTER
            elif d == 2:
                return WIK_RIGHT
        else:
            cprint('##############=============> We suggest 过', 'green', attrs=self.pattrs)
            return 0
    def print_myhand(self):
        self.hand.sort()
        ret = ''
        for i in self.hand:
            ret += CARDS[i]+'|'
        print('=======> my hand: ', ret)
    def no_op(self):
        cprint('##############=============> We suggest 过', 'green', attrs=self.pattrs)
    def chi_hu(self):
        self.can_hu = True
        cprint('##############=============> We suggest 胡', 'green', attrs=self.pattrs)
    def zi_mo(self):
        cprint('##############=============> We suggest 自摸', 'green', attrs=self.pattrs)
    def fan(self):
        return self.double
    def should_hu(self):
        if self.me_richer:
            return False
        if not self.isus:
            return True
        if self.fan() < self.target:
            return False
        return True

min_workers = 2
def play_game(mac=None, filename=None, live=False):
    if mac:
        if take_all_prize:
            prize(mac, take_all=True)
        conn = WSGameConnection(game_port)
        c = login(mac, game_port) ## login('ffffffff-e184-87b9-ffff-ffffa7b1fa34')
        userID, pwd, my_score, medal_task = int(c['userId']), c['pwd'], c['score'], c['medals']
    else:
        conn = PcapGameConnection(filename=filename, live=live)
        userID, pwd, my_score, medal_task = 123, 'password', 999, 0
    print_medal = False
    login_pkt = SUB_GS_LOGON_USERID(userID, pwd)
    conn.send_message(login_pkt.ser())
    me_id = 0
    while True:
        msg = conn.get_message()
        #print('==> ', msg)
        msg = PKT.decode(msg)
        print(msg)
        if type(msg) == SUB_GS_SYSMESSAGE and msg.type == 20483:
            conn.close()
            print(msg)
            break
        if type(msg) == SUB_GS_USER_SCORE:
            me_id = msg.dwUserID
            #my_score = msg.lScore
            print('login done')
            break
#     return
    hbk = HBKeeper(conn)
    hbk.daemon = True
    hbk.start()
    def join_table():
        hbk.need_work = True
        set_score(me_id, my_score)
        go_together(userID, min_workers)
        hbk.need_work = False
        print('gogogo')
        conn.send_message(SUB_GS_USER_JOIN_RANDOM_LIST_SYN().ser())
    join_table()
    me_chair = -1
    g = None
    def out_card():
        t = g.me_worst_tile()
        #print('^^^^^^^^^^^^^^--> ', SUB_C_OUT_CARD(t))
        g.me_out(t)
        conn.send_message(SUB_C_OUT_CARD(t).ser())
    while True:
        msg = conn.get_message()
        msg = PKT.decode(msg)
        #print(msg)
        if type(msg) == SUB_S_START_SEND_CARD:
            target = 7
            if game_port == '17311':
                target = 9
            g = VGame(is_usus, me_richer, me_id, enemy_userID, target)
            g.me_init_hand(msg.tiles)
            if msg.wBankerUser == me_chair:
                out_card()
            else:
                g.hand.remove(0)
        elif type(msg) == HEAT_BEAT:
            conn.send_message(msg.ser())  # send it back
        elif type(msg) == SUB_GS_SYSMESSAGE and msg.type == 20483:
            conn.close()
            print(msg)
            break
        elif type(msg) == SUB_S_OUT_CARD:
            if me_chair == msg.user:
                #g.me_out(msg.tile)
                pass
            else:
                g.enemy_out(msg.tile)
        elif type(msg) == SUB_GS_USER_COME:
            enemy_userID, enemy_score = msg.info['id'], msg.info['lScore']
            #enemy_userID = msg.info['id']
            if is_us(enemy_userID):
                is_usus = True
            else:
                is_usus = False
            if is_usus:
                try:
                    enemy_score = get_score(enemy_userID)
                except:
                    print('oops')
            me_richer = is_usus and my_score > enemy_score
        elif type(msg) == SUB_GS_USER_STATUS:
            if me_id == msg.userID:
                me_chair = msg.chairID
                if msg.status == 1:
                    if os.path.exists('stop'): break
                    join_table()
                if msg.status == 2:
                    conn.send_message(SUB_GS_INFO().ser())
        elif type(msg) == SUB_S_SEND_CARD:
            if me_chair == msg.user:
                g.me_draw_tile(msg.tile)
                t = g.me_worst_tile(); t2 = t
                msg = conn.get_message(timeout=0.03)
                need_out_card = True
                if msg: 
                    msg = PKT.decode(msg)
                    if type(msg) == SUB_S_OPERATE_NOTIFY:
                        print(msg)
                        m = msg.cbActionMask
                        t = msg.cbActionCard
                        op = SUB_C_OPERATE_CARD()
                        op.tile = t
                        if m & WIK_CHI_HU:
                            g.chi_hu()
                            op.action = WIK_CHI_HU
                            need_out_card = False
                        elif m & WIK_ZI_MO:
                            g.zi_mo()
                            op.action = WIK_ZI_MO
                            need_out_card = False
                        elif m & WIK_GANG:
                            g.no_op()
                            op.action = 0
                            op.tile = 0
                        if m & WIK_CHI_HU and not g.should_hu():
                            g.no_op()
                            op.action = 0
                            op.tile = 0
                            t = t2
                        conn.send_message(op.ser())
                if need_out_card:
                    #print('^^^^^^^^^^^^^^2--> ', SUB_C_OUT_CARD(t))
                    g.me_out(t)
                    conn.send_message(SUB_C_OUT_CARD(t).ser())
        elif type(msg) == SUB_S_OPERATE_NOTIFY:
            m = msg.cbActionMask
            t = msg.cbActionCard
            op = SUB_C_OPERATE_CARD()
            op.tile = t
            actions = WIK_LEFT | WIK_CENTER | WIK_RIGHT | WIK_PENG
            if m & WIK_CHI_HU:
                g.chi_hu()
                op.action = WIK_CHI_HU
                if not g.should_hu():
                    if actions & m:
                        op.action = g.operate_tile(t, m)
                        if op.action == 0: op.tile = 0
                    else:
                        op.action = 0; op.tile = 0
            elif m & WIK_ZI_MO:
                g.zi_mo()
                op.action = WIK_ZI_MO
            elif actions & m:
                op.action = g.operate_tile(t, m)
                if op.action == 0: op.tile = 0
            elif m & WIK_GANG:
                g.no_op()
                op.action = 0
                op.tile = 0
            conn.send_message(op.ser())
        elif type(msg) == SUB_S_OPERATE_RESULT:
            cbOperateCode = msg.cbOperateCode
            cbOperateCard = msg.cbOperateCard
            if cbOperateCode:
                cards = []
                if cbOperateCode == WIK_LEFT:
                    cards = [cbOperateCard+1, cbOperateCard+2]
                elif cbOperateCode == WIK_CENTER:
                    cards = [cbOperateCard-1, cbOperateCard+1] 
                elif cbOperateCode == WIK_RIGHT:
                    cards = [cbOperateCard-2, cbOperateCard-1] 
                elif cbOperateCode == WIK_PENG:
                    cards = [cbOperateCard, cbOperateCard] 
                elif cbOperateCode == WIK_GANG:
                    cards = [cbOperateCard, cbOperateCard, cbOperateCard]
                if msg.wOperateUser == me_chair:
                    for i in cards:
                        g.me_out(i)
                    out_card()
            else:
                if len(g.hand) % 3 == 2:  # when we can zi_mo but we choose not to
                    out_card()
        elif type(msg) == SUB_S_GAME_END:
            my_score = my_score + msg.lGameScore[me_chair] - msg.lTaiFei
            update_score(me_id, my_score)
            update_medal(me_id, medal_task)
            txt = 'GameScore[%d] WT[%d] Score[ %d | %d ] M[%d] IDS[ %s | %s ]'%(msg.lGameScore[me_chair],
                    msg.lWinTimes[me_chair], my_score//10000, my_score, medal_task, me_id, enemy_userID)
            cprint(txt, 'green', attrs=['underline'] if is_usus else [])
            if msg.lGameScore[me_chair] == 0:
                conn.close()
                break
            #if abs(msg.lWinTimes[me_chair]) > 128:
            #    conn.close()
            #    break
        elif type(msg) == SUB_GS_USER_SCORE and msg.dwUserID == me_id:
            txt = 'MyScore[%d] WinLostRate[%d/%d]'%(msg.lScore, msg.lWinCount, msg.lLostCount)
            #my_score = msg.lScore
            cprint(txt, 'green', attrs=['underline'] if is_usus else [])
        elif type(msg) == SUB_GS_USER_TASK_INFO:
            for i in msg.task_infos:
                if i['eRewardsType'] == 2 and i['bIsFinished']:
                    medal_task += i['RewardsNums']
            txt = 'Medals[%d]' % medal_task
            if print_medal: 
                cprint(txt, 'green', attrs=['underline'] if is_usus else [])
            print_medal = not print_medal
    conn.close()        

####################################################################
## redis part

from redis import StrictRedis
import time
import random

redis = StrictRedis(host='localhost', port=6379)

min_worker = 3

ps = redis.pubsub()


def go_together(worker_name, min_worker=3):
    try:
        if os.path.exists('workers.conf'):
            min_worker = int(open('workers.conf').read())
    except:
        print('Oops')
    while True:                ## consume old messages
        m = ps.get_message()
        if not m:
            break
    redis.hset(worker_state_key, worker_name, 'ready')
    ws = redis.hgetall(worker_state_key)
    ready_workers = [i for i in ws if ws[i] == b'ready']
    if len(ready_workers) >= min_worker:
#         print('gogogogooggoogogogogog')
        redis.publish(redis_ps_channel, 'gogogo')
    else:
        for m in ps.listen():
            if m['type'] == 'message':
#                print(m)
#                 ps.unsubscribe('go')
                break
    cprint('gogogogogogogogo', 'yellow')
    redis.hset(worker_state_key, worker_name, 'busy')
    
def is_us(userid):
    return redis.hget(worker_state_key, userid)
    
def enemy_wanted_list(userid):
    ret = redis.get(userid)
    if ret:
        ret = json.loads(redis.get(userid).decode('utf-8'))
    return ret

def set_score(userid, score):
    redis.set('score_%s'%userid, score)

def get_score(userid):
    return int(redis.get('score_%s'%userid))

def update_score(userid, score):
    redis.hset('worker_scores', userid, score)
    
def update_medal(userid, score):
    redis.hset('worker_medals', userid, score)
    
class HBKeeper(threading.Thread):
    def __init__(self, conn):
        threading.Thread.__init__(self)
        self.conn = conn
        self.need_work = False
    def run(self):
        while True:
            if self.need_work:
                if os.path.exists('stop'):
                    self.conn.close()
                    os._exit(0)
                msg = self.conn.get_message(timeout=0.03)
                if msg:
                    msg = PKT.decode(msg)
                    if type(msg) == HEAT_BEAT:
                        print('got HEAT_BEAT')
                        self.conn.send_message(msg.ser())  # send it back
                    else:  ## should not happen
                        print('###########################################################')
                        print('###########################################################')
                        print(msg)
            time.sleep(1)

import sys

		
# play_game(filename = '/tmp/0605.pcap')


mac = 'ffffffff-e184-87ba-ffff-ffffa7b1fa34'
game_port = 17301
take_all_prize = False
stop = False
if len(sys.argv) > 1:
    mac = sys.argv[1]
if len(sys.argv) > 2:
    min_workers = int(sys.argv[2])
if len(sys.argv) > 3:
    game_port = sys.argv[3]
if len(sys.argv) > 4:
    take_all_prize  = True

worker_state_key = 'worker_state_%s'%game_port

redis_ps_channel = 'go_%s'% game_port
ps.subscribe(redis_ps_channel)

play_game(mac = mac)

