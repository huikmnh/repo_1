import random,sys


# while sys.stdin.readline():
#   print(random.randint(0,10), ' + ', random.randint(0,10))


import curses
# from curses import wrapper


def wrapper(func, *args, **kwds):
    """Wrapper function that initializes curses and calls another function,
    restoring normal keyboard/screen behavior on error.
    The callable object 'func' is then passed the main window 'stdscr'
    as its first argument, followed by any other arguments passed to
    wrapper().
    """

    try:
        # Initialize curses
        stdscr = curses.initscr()

        # Turn off echoing of keys, and enter cbreak mode,
        # where no buffering is performed on keyboard input
        curses.noecho()
        curses.cbreak()
        curses.curs_set(False)

        # In keypad mode, escape sequences for special keys
        # (like the cursor keys) will be interpreted and
        # a special value like curses.KEY_LEFT will be returned
        stdscr.keypad(1)

        # Start color, too.  Harmless if the terminal doesn't have
        # color; user can test with has_color() later on.  The try/catch
        # works around a minor bit of over-conscientiousness in the curses
        # module -- the error return from C start_color() is ignorable.
        try:
            curses.start_color()
        except:
            pass

        return func(stdscr, *args, **kwds)
    finally:
        # Set everything back to normal
        if 'stdscr' in locals():
            stdscr.keypad(0)
            curses.echo()
            curses.nocbreak()
            curses.endwin()


# curses.cbreak()

import json

def load_records():
    ret = [['1+2',1, []], ['2+3',0,[]]]
    return ret

def save_records(file_name='egg.dat'):
    

def main(stdscr):
    # Clear screen
#     stdscr.cbreak()
    while True:
        stdscr.move(20,20)
        k = stdscr.getkey()
        stdscr.clear()
#         break
        if k == 'q' or k == 'Q':
            break
        cont = '{0} + {1}'.format(random.randint(0,10), random.randint(0,10))
        stdscr.addstr(0, 0, cont)
#     # This raises ZeroDivisionError when i == 10.
#     for i in range(0, 11):
#         v = i-10
#         stdscr.addstr(i, 0, '10 divided by {} is {}'.format(v, v))
#         stdscr.refresh()
#     stdscr.getkey()

wrapper(main)