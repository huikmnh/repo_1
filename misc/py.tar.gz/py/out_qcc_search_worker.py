import time, datetime, random
import json, requests
import binascii
import urllib, sys


t = "6dc0ddc660d5f7b53da96e0e8c1a5668"

if len(sys.argv) > 1:
    t = sys.argv[1]

Headers= {
'charset':          'utf-8',
'Accept-Encoding':  'gzip',
'referer':          'https://servicewechat.com/wx395200814fcd7599/46/page-frame.html',
'content-type':     'application/json',
'User-Agent':       'Mozilla/5.0 (Linux; Android 7.1.1; GT-N7100 Build/NMF26V; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/52.0.2743.100 Mobile Safari/537.36 MicroMessenger/7.0.3.1400(0x27000334) Process/appbrand0 NetType/WIFI Language/zh_CN',
'Connection':       'Keep-Alive'
}

def qcc_search_wx(dwmc):
    url = 'https://xcx.qichacha.com/wxa/v1/other/searchProducts?pageIndex=1&searchKey=%s&province=&cityCode=&token=%s' % (urllib.parse.quote(dwmc), t)
    url2 = 'https://xcx.qichacha.com/wxa/v1/base/advancedSearchNew?searchKey=%s&searchIndex=&sortField=&isSortAsc=false&province=&cityCode=&countyCode=&industryCode=&subIndustryCode=&industryV3=&token=%s&startDateBegin=&startDateEnd=&registCapiBegin=&registCapiEnd=&insuredCntStart=&insuredCntEnd=&coyType=&statusCode=&hasPhone=&hasMobilePhone=&hasEmail=&hasTM=&hasPatent=&hasSC=&hasShiXin=&hasFinance=&hasIPO=&pageIndex=1&searchType=0' % (dwmc, t)
    resp = requests.request('GET', url2, headers=Headers)
    return resp.text

def get_search_work():
    url = 'http://localhost:8000/search'
    url = 'http://180.168.251.201:20003/search'
    resp = requests.request('GET', url)
    return resp.text

def now():
    return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]


es_host = 'localhost:9200'
es_host = '180.168.251.201:20004'
import elasticsearch, elasticsearch.helpers
es = elasticsearch.Elasticsearch([es_host])

def str_key(a):
    return binascii.hexlify(a.encode('utf-8')).decode()

def work_1():
    body = {"query":{"bool":{"must":[{"term":{"SRC":{"value":"2"}}},{"term":{"worked":{"value":0}}}]}}}
    al = elasticsearch.helpers.scan(client=es, index='input_dwxx', size=5000, query=body)
    n = 0
    for j in al:
        n += 1
        a = j['_source']
        if n % 100 == 0:
            print('Got %d rows' % n)
        dwmc = a['DWMC']
        resp_txt = qcc_search_wx(dwmc)
        resp = json.loads(resp_txt)
        print(resp_txt)
        if resp['status'] != 200:
            print('Something goes wrong!!!')
            print(resp)
            break
        es.index(index='search_cache', doc_type='doc', id=str_key(dwmc), body={'DWMC':dwmc, 'raw':resp_txt, 'ts':now()}, refresh=True)
        es.update(index='input_dwxx', doc_type='dwxx', id=str_key(dwmc), body={"script":"ctx._source.worked += 1"}, refresh=True)
        print('Searched [%s]'%dwmc)
        time.sleep(random.randint(5, 20)/10)

def work_2():
    while True:
        dwmc = get_search_work()
        if dwmc == 'No more works':
            break
#         dwmc = a['DWMC']
        resp_txt = qcc_search_wx(dwmc)
        resp = json.loads(resp_txt)
        print(resp_txt)
        if resp['status'] != 200:
            print('Something goes wrong!!!')
            print(resp)
            break
        es.index(index='search_cache', doc_type='doc', id=str_key(dwmc), body={'DWMC':dwmc, 'raw':resp_txt, 'ts':now()}, refresh=True)
        es.update(index='input_dwxx', doc_type='dwxx', id=str_key(dwmc), body={"script":"ctx._source.worked += 1"}, refresh=True)
        print('Searched [%s]'%dwmc)
        time.sleep(random.randint(5, 20)/10)
        
        
work_2()
