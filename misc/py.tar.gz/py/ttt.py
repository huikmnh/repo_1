from scapy.all import *
import struct

class TcpStream():
    def __init__(self, pkt):
        self.init = True
        if 'Raw' in pkt:
            self.data = pkt[Raw].load
#             self.data = b''
            self.nseq = pkt[TCP].seq + len(self.data)
            print('---> ', self.nseq, pkt[TCP].seq, )
        else:
            self.data = b''
            if pkt[TCP].flags & 2 == 2:
                self.nseq = pkt[TCP].seq  + 1
    def add_packet(self, pkt):
        if pkt[TCP].seq != self.nseq:
            print(pkt[TCP].seq, self.nseq)
            print('Oops')
            return
        if 'Raw' in pkt:
            self.data += pkt[Raw].load
            self.nseq = pkt[TCP].seq + len(pkt[Raw].load)
            if self.init:
                if pkt[Raw].load[:2] == b'ES':
                    self.init = False
                    self.c = len(self.data) - len(pkt[Raw].load)
            print('******> ', self.data)
            if not self.init:
#                 print('**********************************************')
                for i in range(5):
                    found_frame = False
#                     print (len(self.data) - self.c - 1, len(self.data), self.c)
                    if len(self.data) - self.c >= 6:
#                         print('1111111111111111111111111111111111')
                        magic, size = struct.unpack('>hi', self.data[self.c:self.c+6])
                        if size == -1: ## ping header
                            self.data = self.data[self.c+6:]
                            self.c = 0
                        else:
                            if len(self.data) - self.c >= 19:
                                magic, size, requestId, status, version_id = struct.unpack('>hiqbi', self.data[self.c:self.c+19])
                                print(size, magic, size, requestId, status, version_id)
                                if len(self.data) - self.c >= size + 6:
                                    content = self.data[self.c+19:self.c+19+size-13]
                                    print('=====> ',content)
                                    if status == 0:
                                        print('############> ', decodeRequest(content))
                                        reqs[requestId] = pkt.time
                                    if status == 1:
                                        try:
                                            t = pkt.time - reqs[requestId]
                                            print('----------> request[%s] use %f sec' % (requestId, t))
                                        except:
                                            pass
                                    self.data = self.data[self.c+19+size-13:]
                                    self.c = 0
                    if not found_frame:
#                         print('##################')
                        break
#                     else:
#                         print('##################')
#                         break
#             print('====>', pkt[TCP].seq, len(pkt[Raw].load))
        else:
#             self.data = ''
            if pkt[TCP].flags & 3 : # SYN or FIN
                self.nseq = pkt[TCP].seq  + 1
    
streams = {}
reqs = {}
def deal_pkt(p):
    if (p[TCP].sport, p[TCP].dport) not in streams:
        if p[TCP].flags == 16:
            pass
        else:
            s = TcpStream(p)
            streams[(p[TCP].sport, p[TCP].dport)] = s
    else:
        s = streams[(p[TCP].sport, p[TCP].dport)]
        s.add_packet(p)
        
import pysmile

def readVInt(buf):
    print(buf)
    ret = 0
    for i in range(5):
        a = buf[i]
        ret += (a&0x7f) << (i*7)
        first = a & 0x80
        if first == 0:
            return ret, buf[i+1:]

def readStr(buf):
    str_len, buf = readVInt(buf)
    s = buf[:str_len]
    return s.decode('utf-8'), buf[str_len:]

def deal_bin(buf):
    ret = bytearray(len(buf))
    for i in range(len(buf)):
        first_bit = buf[i] & 0x80
        if first_bit:
            ret[i] = ord('^')
        else:
            ret[i] = buf[i]
    return ret

def decodeRequest(buf):
    ret = {}
    s, buf = readStr(buf)
    ret['action'] = s
    if s != 'indices:data/read/search':
        return s, buf
    header_flag = buf[0]
    assert(header_flag == 0)
    buf = buf[1:]
    search_type = buf[0]
    buf = buf[1:]
    indices_count, buf = readVInt(buf)
    indices = []
    ret['indices'] = indices
    print(buf)
    for i in range(indices_count):
        s, buf = readStr(buf)
        indices.append(s)
    s, buf = readStr(buf)
    ret['routing'] = s
    s, buf = readStr(buf)
    ret['preference'] = s
    scroll_flag = buf[0]
    assert(scroll_flag == 0)
    buf = buf[1:]
    source_len, buf = readVInt(buf)
    source_bin, buf = buf[:source_len], buf[source_len]
    print(source_len)
    print(source_bin)
    ret['source'] = pysmile.decode(source_bin)
#     ret['source_2'] = deal_bin(source_bin)
    return ret
    
streams = {}
sniff(prn=deal_pkt, offline='/tmp/zushou/t3.pcap', filter='src port 51810')
# sniff(prn=deal_pkt, offline='/tmp/suzhou.pcap')
