#!/usr/bin/env python
# coding: utf-8

# In[1]:


import os

works = os.listdir('.')
works = [i for i in works if i.endswith('_dem.tif')]

import concurrent.futures
import os

def work(f_name):
    outFileName = f_name[:-4]+'_30.tif'
    if os.path.exists(outFileName) and os.stat(outFileName).st_size == 233409756:
        print('skip %s' % f_name)
        return
    print('processing %s' % f_name) 
    os.system('python3 tiff_interp.py %s' % f_name)

def do_all(max_threads = 8):
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_threads) as executor:
        for i in works:
            executor.submit(work, i)
#             print('processing %s' % i) 
        executor.shutdown()
    print('Done')


# In[4]:


#get_ipython().magic('time do_all()')
do_all()
