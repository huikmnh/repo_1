es_host = 'localhost:9200'
import elasticsearch, elasticsearch.helpers
es = elasticsearch.Elasticsearch([es_host])

import threading
LOCK = threading.Lock()

from http.server import HTTPServer, BaseHTTPRequestHandler

from io import BytesIO

search_works = []

class SimpleHTTPRequestHandler(BaseHTTPRequestHandler):
    
    def get_search_works(self):
        body = {"query":{"bool":{"must":[{"term":{"SRC":{"value":"1"}}},{"term":{"worked":{"value":0}}}]}}}
        al = es.search(index='input_dwxx',body=body, size=1000)['hits']['hits']
        for i in al:
            search_works.append(i['_source']['DWMC'])
            
    def get_search_work(self):
        if not search_works:
            self.get_search_works()
        if search_works:
            return search_works.pop()
        return None

    def do_GET(self):
        with LOCK:
#             print(dir(self))
#             print(self.path)
            if self.path == '/search':
                a = self.get_search_work()
                if a:
                    self.send_response(200)
                    self.end_headers()
                    self.wfile.write(a.encode('utf-8'))
                    return
                else:
                    self.send_response(201)
                    self.end_headers()
                    self.wfile.write(b'No more works')
                    return
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b'Hello, world!\n')

    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        body = self.rfile.read(content_length)
        self.send_response(200)
        self.end_headers()
        response = BytesIO()
        response.write(b'This is POST request. ')
        response.write(b'Received: ')
        response.write(body)
        self.wfile.write(response.getvalue())


httpd = HTTPServer(('localhost', 8000), SimpleHTTPRequestHandler)
httpd.serve_forever()