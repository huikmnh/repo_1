import json

meta = json.load(open('/tmp/meta.m30.json'))

import os, time, sys
os.chdir('/root/bt/new/dem.30m')


c = 'csrftoken=uVbxFhJ57vk2v15rSCg8clZvFxUHKsop; _next_="/sources/download/305/srtm_01_12/bj"; gscloud_session=h7qwsgaofgj3oit7q8txc7749i35tzko; utoken="ut:ZWacJHyGiwwt9Ax18eXMAL4t"'
if len(sys.argv) > 1:
    c = sys.argv[1]

for i in meta['data']:
    a = i['dataid']
    row = i['row']
    col = i['path']
    sub_p = '%s'%(row,)
    if not os.path.exists(sub_p):
        os.makedirs(sub_p)
    flag_file = '%s/%s.ok'%(sub_p,a)
    data_file = '%s/%s.img.zip'%(sub_p,a)
    if os.path.exists(flag_file):
        print('%s OK'%data_file)
        continue
    else:
        if os.path.exists(a):
            continue
        else:
            open(a, 'w').close()
            if os.system('unzip -t %s'%data_file) == 0:
                open(flag_file, 'w').close()
                print('%s OK'%data_file)
            else:
                time.sleep(2)
                cmd='''curl --retry 3 -L http://www.gscloud.cn/sources/download/421/%s/bj --cookie '%s' -o %s'''%(a, c, data_file)
                os.system(cmd)
                if os.system('unzip -t %s'%data_file) == 0:
                    open(flag_file, 'w').close()
                    print('%s OK'%data_file)
            os.unlink(a)