

import gedecode

a = b'aello'
b = bytearray(a)

gedecode.gedecode(b)

print(b)

