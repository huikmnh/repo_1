#!/usr/bin/env python3

from gecommon import *

def check():
    for dirpath, dnames, fnames in os.walk(archive_path):
        for f in fnames:
            if f.endswith('.tar'):
                f_check = os.path.join(dirpath, f+'.md5')
                f_full = os.path.join(dirpath, f)
                if not os.path.exists(f_check):
                    logging.info('checking %s ...'%f_full)
                    os.system('bash -c "cd %s; md5sum %s > %s"'%(dirpath, f, f_check))
                    
check()