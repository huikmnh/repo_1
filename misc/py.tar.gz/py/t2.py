import requests

def http_get(url):
    resp = requests.request('GET', url)
    return resp.content

import time

print(http_get('https://www.baidu.com').decode('utf-8'))

time.sleep(1000)