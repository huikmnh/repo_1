#!/usr/bin/env python3

from gecommon import *

import queue
import threading

# log.info('hello')


def push_work(level):
    es.update(index='map_work', doc_type='work', id=level, body={
                        'doc':{'status':'downloading'}}, refresh=True)       

def work_done(level):
    for i in range(5):
        try:
            es.update(index='map_work', doc_type='work', id=level, body={
                            'doc':{'status':'done'}}, timeout='30s', request_timeout=30)  
            return
        except:
            traceback.print_exc()
            time.sleep(10)
            pass

def get_global_work():
    body = {"query":{"bool":{"must":[{"term":{"worker":{"value":"none"}}},{"term":{"status":{"value":"waiting"}}}]}},
            "sort":[{"levels":{"order":"asc"}}]}
    while True:
        al = es.search(index='map_work', size=1, body=body, version=True)
        if not al['hits']['hits']:
            return None
        else:
            row = al['hits']['hits'][0]
            ver = row['_version']
            try:
                es.update(index='map_work', doc_type='work', id=row['_id'], version=ver, body={
                        'doc':{'worker':host_id, 'status':'downloading'}
                    }, refresh=True)
                print('********** global', row['_id'])
                return row['_id']
            except elasticsearch.ConflictError:
                continue    

own_works = []
def get_own_work_2():  ## should only be called once
    body = {"query":{"bool":{"must":[{"term":{"worker":{"value":host_id}}},{"term":{"status":{"value":"downloading"}}}]}},
           "sort":[{"level":{"order":"asc"}}]}
    al = es.search(index='map_work', size=1000, body=body)
    if not al['hits']['hits']:
        return None
    for row in al['hits']['hits']:
        own_works.append(row['_id'])
#         row = al['hits']['hits'][0]
#         print('********** own', row['_id'])
    return row['_id']

get_own_work_2()

def get_own_work():
    if own_works:
        o = own_works.pop()
        print('********** own', o)
        return o
    return None

def get_own_work():
    while own_works:
        o = own_works.pop()
        print('********** own', o)
        if os.path.exists(archive_fn(o)):
            print('******** Ignoring %s'%o)
            continue
        return o
    return None

def dir_empty(path):
    for i in os.listdir(path):
        if len(i) != 4:
            return False
    return True

def levels_2_path(levels):
    ret = []
    while levels:
        if len(levels) < 4:
            break
        ret.append(levels[:4])
        levels = levels[4:]
    return '/'.join(ret)

def archive_fn(level):
    p = levels_2_path(level)
    out_p = os.path.join(archive_path, p)
    out_fn = os.path.join(out_p, level+'.tar')
    return out_fn

def archive_level(level):
    out_fn = ''
    assert len(level) == 12
    if len(level) >= 12:
        p = levels_2_path(level)
        assert os.path.exists(p)
        assert not dir_empty(p)
        out_p = os.path.join(archive_path, p)
#         print('*******', out_p)
        if not os.path.exists(out_p):
            pathlib.Path(out_p).mkdir(parents=True, exist_ok=True) 
        out_fn = os.path.join(out_p, level+'.tar')
        out_fn_tmp = os.path.join(out_p, level+'.tar.tmp')
        os.system('bash -c "cd %s ; tar --remove-files --create -f %s *; md5sum %s > %s.md5 "' % (p, out_fn_tmp, out_fn_tmp, out_fn))
        os.rename(out_fn_tmp, out_fn)
#         os.sync()
            
def get_work():
    body = {"query":{"bool":{"must":[{"term":{"status":{"value":"downloaded"}}},{"term":{"level":{"value":12}}},
                                     {"prefix":{"worker":{"value":host_id}}}]}},"sort":[{"levels":{"order":"asc"}}]}
    al = es.search(index='map_work', size=1, body=body)
    if not al['hits']['hits']:
        return None
    row = al['hits']['hits'][0]
    candidate = row['_id']
    body = {"query":{"bool":{"must":[{"prefix":{"status":{"value":"downloading"}}},{"prefix":{"levels":{"value":candidate}}}]}}}
    al = es.search(index='map_work', size=1, body=body)
    workings = al['hits']['total']
    if workings == 0:
        return candidate
    else:
        print('waiting %d works to be done for %s'%(workings, candidate))
        return None
            
# def go():
#     while True:
#         if os.path.exists('quit'): break
#         try:
#             level = get_work()
#         except:
#             traceback.print_exc()
#         if not level:
#             time.sleep(2)
#         else:
#             try:
#                 print('archiveing %s'%level)
#                 archive_level(level)
#                 work_done(level)
#                 logging.info('%s Done'%level)
#                 time.sleep(1)
#             except:
#                 traceback.print_exc()
            
# go()


gq = queue.Queue() ## work queue
aq = queue.Queue() ## archive queue

def archive_worker():
    items = {}
    while True:
        try:
            t, o = aq.get()
            if t == 'NEW12':
                items[o[0]] = set(o)
            if t == 'DONE':
                level12 = o[:12]
                try:
                    a = items[level12]
                    a.remove(o)
                except:
                    debug = {i:len(items[i]) for i in items}
                    try:
                        print('ssss ==>', debug[level12])
                    except:
                        pass
#                 print('==== %s done'%o)
                level = level12
                if len(a) == 0:
                    print('archiveing %s'%level)
                    archive_level(level12)
                    work_done(level)
                    logging.info('%s Done'%level)
                    del items[level12]
                    debug = {i:len(items[i]) for i in items}
                    print('repo ==>', debug)
        except:
            traceback.print_exc()

t = threading.Thread(target=archive_worker)
t.start()

# def inorder_collect(node):
#     flags = node.flags
#     if flags & 0x10: ## have subtree
#         assert len(tree_path) == 4
#     for i in range(4):
#         subnode = node._subnodes[i]
#         if subnode:
#             inorder_download(httpclient, subnode, path_name, prefix, '%s%d'%(tree_path,i))

def inorder_collect(collecter, node, prefix=''):
    flags = node.flags
    if flags & 0x10: ## have subtree
        collecter.append(prefix)
    for i in range(4):
        sub_node = node._subnodes[i]
        if sub_node:
            inorder_collect(collecter, sub_node, '%s%d'%(prefix,i))    

def deal_qp(level, ver = 876):
    code, qp = hc.get('https://kh.google.com/flatfile?q2-%s-q.%d'%(level,ver))
    qp = decrypt(qp)
    assert struct.unpack('i', qp[4:8])[0] == len(zlib.decompress(qp[8:]))
    qp = zlib.decompress(qp[8:])
    header, qtp = decode_qtpacket(qp)
    coll = []
    inorder_collect(coll, qtp)
#     print('********', coll)
    ret = [level]
    gq.put(level)
    for i in coll:
        ret.append(level+i)
        gq.put(level+i)
    aq.put(('NEW12', ret))
    return ret


host     = "localhost"
port   = 29999
bufferSize  = 1024

asock = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)
asock.bind((host, port))


def go():
    while True:
        msg, addr = asock.recvfrom(bufferSize)
        ret = ''
        done_work = msg.decode()
        if done_work:
            aq.put(('DONE', done_work))
        if gq.empty():
            level = get_own_work()
            err = False
            if not level:
                try:
                    level = get_global_work()
                except:
                    traceback.print_exc()
                    err = True
            if err:
                ret = 'RETRY'
            else:
                if not level:
                    print('nothing to do')
                    time.sleep(2)
                else:
                    try:
                        deal_qp(level)
                    except:
                        traceback.print_exc()
                    ret = 'RETRY'
        else:
            level = gq.get()
            ret = level
        raw = ret.encode()
        asock.sendto(raw, addr)

go()
        
# httpd = HTTPServer(('localhost', 9000), SimpleHTTPRequestHandler)
# httpd.serve_forever()