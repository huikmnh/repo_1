from distutils.core import setup, Extension

module1 = Extension('gedecode',
                    sources = ['gedecode.c'])

setup (name = 'gedecode',
       version = '1.0',
       description = '',
       ext_modules = [module1])
