import struct
import inspect
import json
import zlib

class RP():
    def __init__(self, filename='/tmp/9.rp'):
        content = open(filename, 'rb').read()
        self.content = content
        c = content
        self.f_2, = struct.unpack('i', c[8:12]) ## file_size
        self.f_1, = struct.unpack('i', c[4:8])  ## header size
        self.f_15, = struct.unpack('i', c[60:64])
        self.f_16, = struct.unpack('i', c[64:68])
        self.f_17, = struct.unpack('i', c[68:72])
        self.f_18, = struct.unpack('i', c[72:76])
        self.f_19, = struct.unpack('i', c[76:80])  ## road names begin
        self.f_20, = struct.unpack('i', c[80:84])  ## road names end, DistrictFrame begin
        self.f_21, = struct.unpack('i', c[84:88])
        self.f_22, = struct.unpack('i', c[88:92])
        self.f_23, = struct.unpack('i', c[92:96])
        self.levels = []
        for i in range(self.f_21):
            vals = struct.unpack('Iiiiiiii', c[self.f_23+self.f_22*i:self.f_23+self.f_22*i+self.f_22])
            keys = ('a_0', 'CalcRegionManagerHeader_pos_1', 'na_2', 'CalcRegionManagerHeader_len_3', 
                    'InfoRegionManagerHeader_pos_4', 'InfoRegionManagerHeader_len_5', 'AdjacentNodeManager_pos_6', 
                    'AdjacentNodeManager_len_7')
            self.levels.append(dict(zip(keys, vals)))
        pass
        ## the name frame part
        name_frame_size, header_size, item_cnt, idx_item_size, header_size_2, names_offset = struct.unpack('iiiiii', c[self.f_19:self.f_19+24])
        assert (header_size, idx_item_size, header_size_2, self.f_19+name_frame_size) == (24, 4, 24, self.f_20)
        all_name = c[self.f_19+names_offset:self.f_20].decode('utf-16')
        names = []
        p = self.f_19+header_size
        for i in range(item_cnt):
            item_len, item_pos = struct.unpack('<bi', c[p:p+4]+b'\x00')
            names.append(all_name[item_pos:item_pos+item_len])
            p += 4
        self.names = names
        ## the info region part
        self.info_region_manager_headers = []
        for level in self.levels:
            header = struct.unpack('iiiiiiiiiiiiiii', c[level['InfoRegionManagerHeader_pos_4']:level['InfoRegionManagerHeader_pos_4']+60])
            zipped_end, region_cnt, idx_item_size = header[11:14]
            assert idx_item_size == 32
            l = {}
            l['zipped_end'], l['region_cnt'], l['regions'] = zipped_end, region_cnt, []
            p =level['InfoRegionManagerHeader_pos_4']
            for i in range(region_cnt):
                data_offset, _, unzipped_len, zipped_len = struct.unpack('iiii', c[p+60+32*i:p+60+32*i+16])
                l['regions'].append((p+data_offset, p+data_offset+zipped_len, unzipped_len))
            self.info_region_manager_headers.append(l)
    def get_info_region_buff(self, level, idx):
        begin, end, unzipped_size = self.info_region_manager_headers[level]['regions'][idx]
        ret = zlib.decompress(self.content[begin:end])
        assert len(ret) == unzipped_size
        return ret
    def __repr__(self):
        atts = {}
        for i in dir(self):
#             print(i)
            if i[0] == '_' or i in ('contentaa', ) :
                continue
            att = self.__getattribute__(i)
            if type(att) == bytes:
                continue
            if inspect.ismethod(att):
                continue
            atts[i] = att
#         print(type(atts))
#         print(atts.keys())
#         return 'gogogo'
        return '%s ==> %s'%('hello',atts.__repr__())

def combine_links(links):
    tails = {}
    heads = {}
    ls = links[:]
    for l in ls:
#         print('----------------')
#         print(l)
#         print(heads)
#         print(tails)
        p = l[:]
        if p[-1] in heads and heads[p[-1]]:
            p = p + heads[p[-1]][0][1:]
            del heads[l[-1]][0]
            del tails[p[-1]]
        if p[0] in tails and tails[p[0]]:
            p = tails[p[0]][0][:-1] + p
            del tails[l[0]][0]
            del heads[p[0]]
        if p[0] not in heads:
            heads[p[0]] = []
        heads[p[0]].append(p)
        if p[-1] not in tails:
            tails[p[-1]] = []
        tails[p[-1]].append(p)
    ret = []
    for i in heads.values():
        ret += i
    return ret

def get_road_points(rp, level=0):
    buckets = {}
    ret = {}
    for idx in range(rp.info_region_manager_headers[level]['region_cnt']):
        buff = rp.get_info_region_buff(level, idx)
        ibf = InfoRegionBuffer(buff)
        for idx_0 in range(ibf.row_count[0]):
            name_idx, link_idx = ibf.get_named_link_info(idx_0)
            ps = ibf.get_path_points(link_idx)
            if name_idx not in buckets:
                buckets[name_idx] = []
            buckets[name_idx].append(ps)
    return buckets

def scale_xy(raw, scale=100000):
    ret = []
    for line in raw:
        l = [(x/scale, y/scale) for x, y in line]
        ret.append(l)
    return ret

def dump_road_points(rp, file_path='/tmp/rp_9.txt', points=None, level=0):
    if not points:
        points = get_road_points(rp, level)
    f = open(file_path, 'w')
#     n = 0
    for name in points:
#         if rp.names[name] == '无名路':
#             continue
#         print('dumping', name, rp.names[name])
        row = {'road_name':rp.names[name], 'links':scale_xy(combine_links(points[name]))}
        f.write(json.dumps(row, ensure_ascii=False))
        f.write('\n')
#         n += 1
#         if n%100 == 0:
#             print('dumped %d lines'%n)
    f.close()
            
class InfoRegionBuffer():
    def __init__(self, raw):
        self.data = raw
        self.offsets = struct.unpack('iiiiiiiiiiii', raw[60:108])
        self.row_size = struct.unpack('hhhhhhhhhhhh', raw[36:60])
        self.row_count = struct.unpack('hhiiihhhhhhi', raw[4:36])
        assert self.row_size == (40, 16, 4, 4, 16, 4, 40, 20, 4, 8, 24, 24)
        pos = 108
        for i in range(12):
#             print(self.offsets[i], pos)
            if self.row_count[i]:
                assert self.offsets[i] == pos
            pos += self.row_count[i]*self.row_size[i]
    def get_path_points(self, idx):
        x, y, n, offset = struct.unpack('iiii', self.data[self.offsets[4]+idx*16:self.offsets[4]+idx*16+16])
        ret = [(x, y)]
        for i in range (n):
            dx, dy = struct.unpack('hh', self.data[self.offsets[3]+(offset+i)*4:self.offsets[3]+(offset+i+1)*4])
            x, y = x+dx, y+dy
            ret.append((x, y))
        return ret
    def get_named_link_points(self, idx):
        t = struct.unpack('iiiiiiiiii', self.data[self.offsets[0]+idx*self.row_size[0]:self.offsets[0]+(idx+1)*self.row_size[0]])
        name_idx, link_idx = t[1], t[7]
        return name_idx, self.get_path_points(link_idx)
    def get_named_link_info(self, idx):
        t = struct.unpack('iiiiiiiiii', self.data[self.offsets[0]+idx*self.row_size[0]:self.offsets[0]+(idx+1)*self.row_size[0]])
        name_idx, link_idx = t[1], t[7]
        return name_idx, link_idx
    def some_test(self):
        p = 108
        row_size = self.row_size[0]
        ids = set()
        for i in range(100):
            row = buff_2_ints(self.data[p+row_size*i:p+row_size*(i+1)])
            ids.add(row[1])
        return ids
    def t2(self):
        p = self.offsets[4]
        row_size = self.row_size[4]
        size = self.row_count[4]
        for i in range(size):
            row = buff_2_ints(self.data[p+row_size*i:p+row_size*(i+1)])
            print(row)
    def t3(self, n=1, a=False):
        p = self.offsets[n]
        row_size = self.row_size[n]
        size = self.row_count[n]
        if not a:
            size=30
        for i in range(size):
            row = buff_2_ints(self.data[p+row_size*i:p+row_size*(i+1)])
            print(row)
    def t4(self):
        p = self.offsets[3]
        row_size = self.row_size[3]
        size = self.row_count[3]
        for i in range(size):
            row = buff_2_int16s(self.data[p+row_size*i:p+row_size*(i+1)])
            print(row)        
            

rp = RP('/tmp/9.rp')
dump_road_points(rp, '/tmp/9_rp.txt')
