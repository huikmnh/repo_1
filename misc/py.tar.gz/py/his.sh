python3 bug.py ffffffff-e184-87b1-ffff-ffffa7b1fa34 1 17301

root     18858 11165 11 14:42 pts/1    00:42:38 python3 bug_3.py 00000000-8eba-2b13-ffff-ffff78dba179 1 17301
root     18905 11189 12 14:42 pts/8    00:45:52 python3 bug_3.py 00000000-544c-ee91-ffff-ffff05f369d8 1 17301
root     18989 11201 12 14:42 pts/9    00:45:39 python3 bug_3.py ffffffff-88a0-47cf-ffff-ffff4742eadc 1 17301
root     19076 11177 12 14:42 pts/5    00:43:48 python3 bug_2.py ffffffff-88a0-47cf-ffff-ffff4742eadc 1 17301
