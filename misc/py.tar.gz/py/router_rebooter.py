#!/usr/bin/env python3

import socket
import time, sys

host     = "localhost"
port   = 39999
bufferSize  = 1024

import logging
log = logging.getLogger('')
log.setLevel(logging.INFO)
format = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
ch = logging.StreamHandler(sys.stdout)
ch.setFormatter(format)
log.addHandler(ch)

sock = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)

sock.bind((host, port))

import re, requests, base64

p = re.compile('<input type="hidden" name="onttoken" id="hwonttoken" value="(.*)">')

def reset_router():
    s = requests.Session()
    resp = s.request('POST', 'http://192.168.1.1/asp/GetRandCount.asp')
    token = resp.content[-32:].decode('utf-8')
    pw = b'aDm8H%MdA'
    pw = base64.encodebytes(pw).decode('utf-8')
    pw = pw.strip()
    user = 'CMCCAdmin'
#     print(pw)
    resp = s.request('POST', 'http://192.168.1.1/login.cgi', data={'UserName':user,'PassWord':pw, 'x.X_HW_Token':token})
    resp = s.request('GET', 'http://192.168.1.1/html/ssmp/devmanage/cmccdevicereset.asp')
#     print(resp.status_code, resp.content.decode('utf-8'), resp.headers)
    page = resp.content.decode('utf-8')
    g = p.search(page)
    print(g.group(1))
    token = g.group(1)
    try:
        resp = s.request('POST', 'http://192.168.1.1/html/ssmp/devmanage/set.cgi?x=InternetGatewayDevice.X_HW_DEBUG.SMP.DM.ResetBoard&RequestFile=html/ssmp/devmanage/cmccdevicereset.asp', data={'x.X_HW_Token':token}, timeout=10)
    except:
        pass ## device rebooted, we alway timed out

last_dealed_msg = 0 

while(True):
    msg, addr = sock.recvfrom(bufferSize)
    if time.time() - last_dealed_msg > 600: ## we only reboot the router no faster than every 10 minutes
#         print('Rebooting router ...')
        logging.info('Rebooting router ...')
        last_dealed_msg = time.time()
        reset_router()
    
#     sock.sendto(bytesToSend, address)