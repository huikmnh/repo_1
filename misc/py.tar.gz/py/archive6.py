#!/usr/bin/env python3

import os, sys, pathlib, subprocess
import time

import logging
import traceback


log = logging.getLogger('')
log.setLevel(logging.INFO)
loge = logging.getLogger('elasticsearch')
loge.setLevel(logging.ERROR)
format = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")


ch = logging.StreamHandler(sys.stdout)
ch.setFormatter(format)
log.addHandler(ch)

# log.info('hello')
def cmd_out(cmd):
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, shell=True)
    (output, err) = p.communicate()

    ## Wait for date to terminate. Get return returncode ##
    p_status = p.wait()
    return output.decode('utf-8').strip()

hn = cmd_out('hostname')

if hn == 'wall':
    es_host = 'localhost:9200'
    server_head = 'localhost'
else:
    es_host = '192.168.1.221:9200'
    server_head = '192.168.1.221'
    
import elasticsearch, elasticsearch.helpers
es = elasticsearch.Elasticsearch([es_host])

archive_path = '/home/map'

def get_host_id():
    mac = cmd_out("ip link show dev `ip route get 1.2.3.4 | grep 1.2.3.4 | awk '{print $5}'` | grep ether | awk '{print $2}' | tr -d :")
    hostname = cmd_out('hostname')
    return '%s.%s'%(hostname, mac)

host_id = get_host_id()

def push_work(level):
    es.update(index='map_work', doc_type='work', id=level, body={
                        'doc':{'status':'downloading'}}, refresh=True)       

def work_done(level):
    es.update(index='map_work', doc_type='work', id=level, body={
                        'doc':{'status':'done'}}, refresh=True)    

def dir_empty(path):
    for i in os.listdir(path):
        if len(i) != 4:
            return False
    return True

def levels_2_path(levels):
    ret = []
    while levels:
        if len(levels) < 4:
            break
        ret.append(levels[:4])
        levels = levels[4:]
    return '/'.join(ret)

def archive_level(level):
    out_fn = ''
    assert len(level) == 12
    if len(level) >= 12:
        p = levels_2_path(level)
        if (not os.path.exists(p)) or dir_empty(p):
            print('download %s again\n'%level)
            push_work(level)
            print(p)
            print(levels_2_path(level))
#             os._exit(3)
            raise Exception('Empty target')
        out_p = os.path.join(archive_path, p)
#         print('*******', out_p)
        if not os.path.exists(out_p):
            pathlib.Path(out_p).mkdir(parents=True, exist_ok=True) 
        out_fn = os.path.join(out_p, level+'.tar')
        out_fn_tmp = os.path.join(out_p, level+'.tar.tmp')
        os.system('bash -c "cd %s ; tar --remove-files --create -f %s *"' % (p, out_fn_tmp))
        os.rename(out_fn_tmp, out_fn)
#         os.sync()
            
def get_work():
    body = {"query":{"bool":{"must":[{"term":{"status":{"value":"downloaded"}}},{"term":{"level":{"value":12}}},
                                     {"prefix":{"worker":{"value":host_id}}}]}},"sort":[{"levels":{"order":"asc"}}]}
    al = es.search(index='map_work', size=1, body=body)
    if not al['hits']['hits']:
        return None
    row = al['hits']['hits'][0]
    candidate = row['_id']
    body = {"query":{"bool":{"must":[{"prefix":{"status":{"value":"downloading"}}},{"prefix":{"levels":{"value":candidate}}}]}}}
    al = es.search(index='map_work', size=1, body=body)
    workings = al['hits']['total']
    if workings == 0:
        return candidate
    else:
        print('waiting %d works to be done for %s'%(workings, candidate))
        return None
            
def go():
    while True:
        if os.path.exists('quit'): break
        try:
            level = get_work()
        except:
            traceback.print_exc()
        if not level:
            time.sleep(2)
        else:
            try:
                print('archiveing %s'%level)
                archive_level(level)
                work_done(level)
                logging.info('%s Done'%level)
                time.sleep(1)
            except:
                traceback.print_exc()
            
go()
