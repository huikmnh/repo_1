#!/usr/bin/python3

############################################################
## game connection part

class GameConnection():
    def get_message(self, timeout=None):
        return None
    def send_message(self, msg):
        pass
    def close(self):
        pass

import socket
from scapy.all import *
class TS():
    def __init__(self, pkt):
        self.init = True
        if 'Raw' in pkt:
#             self.data = pkt[Raw].load
            self.data = b''
            self.nseq = pkt[TCP].seq + len(self.data)
        else:
            self.data = b''
            if pkt[TCP].flags & 2 == 2:
                self.nseq = pkt[TCP].seq  + 1
    def add_packet(self, pkt):
        ret = []
        if pkt[TCP].seq != self.nseq:
#             print(pkt[TCP].seq, self.nseq)
#             print('Oops')
            return ret
        if 'Raw' in pkt:
            self.data += pkt[Raw].load
            self.nseq = pkt[TCP].seq + len(pkt[Raw].load)
            if self.init:
                head = self.data.find(b'\r\n\r\n')
                if head > 0:
                    begin = head+4
                    self.init = False
                    self.c = begin
            if not self.init:
                for i in range(5):
                    found_frame = False
                    if len(self.data) - self.c >= 2:
                        ws_op, ws_len = struct.unpack('BB', self.data[self.c:self.c+2])
                        ll = 0
                        mm = 0
                        mask_flag = ws_len & 0x80
                        ws_len = ws_len & 0x7f
                        if mask_flag > 0: mm = 4
                        if ws_len == 126:
                            ll = 2
                            if len(self.data) - self.c >= 2+ll+4:
                                ws_len = struct.unpack('>H', self.data[self.c+2:self.c+4])[0]
                        if len(self.data) - self.c >= 2+ll+mm+ws_len:
                            payload = self.data[self.c+2+ll+mm:self.c+2+ll+mm+ws_len]
                            if mask_flag == 0:
                                masks = b'\x00\x00\x00\x00'
                            else:
                                masks = self.data[self.c+2+ll:self.c+2+ll+4]
                            if mask_flag: 
                                payload = unmask_payload(payload, masks)
                            if ws_op == 0x82:
                                ret.append((payload, mask_flag))
                            found_frame = True
                            self.c += 2+ll+mm+ws_len
                            self.data = self.data[self.c:]
                            self.c = 0
                    if not found_frame:
                        break
        else:
            if pkt[TCP].flags & 3 : # SYN or FIN
                self.nseq = pkt[TCP].seq  + 1
        return ret

class PcapGameConnection(GameConnection):
    def __init__(self, filename=None, live=False):
        self.msgs = []
        self.to = None
        if filename:
            self.pkts = []
            def dp(pkt):
                self.pkts.append(pkt)
            sniff(prn=dp, offline=filename)
#             print(self.pkts)
            self.pkts = iter(self.pkts)
        if live:
            self.sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sk.bind(('0.0.0.0', 8989))
        def message_gen():
            ss = {}
#             n = 0
            while True:
#                 print('n -> ', n)
                if self.msgs:
                    yield self.msgs[0]
                    del self.msgs[0]
                else:
                    if filename and not live:
                        p = next(self.pkts)
                    if live:
                        try:
                            self.sk.settimeout(self.to)
                            data, addr = self.sk.recvfrom(8192)
                        except socket.timeout:
                            yield None, 0
                        except:
                            self.sk = None
                        p = Ether(data)
                    if (p[TCP].sport, p[TCP].dport) not in ss:
                        s = TS(p)
                        ss[(p[TCP].sport, p[TCP].dport)] = s
                    else:
                        s = ss[(p[TCP].sport, p[TCP].dport)]
                        ms = s.add_packet(p)
                        self.msgs += ms
#                 n += 1
        self.msg_gen = message_gen()
    def deal_pkt(self):
        pass
    def get_message(self, timeout=None):
        self.to = timeout
        while True:
            msg, mask = next(self.msg_gen)
            if msg == None:    ## when live mode and no notify
                return None
            if not timeout:
                if mask == 0:
                    return msg
                else:
                    if type(PKT.decode(msg)) == HEAT_BEAT: continue
                    if msg != self.send_buf:
                        cprint('################### send payload mismatch ######################', 'yellow')
                        print(msg)
                        print(self.send_buf)
                        print(PKT.decode(msg))
                        print(PKT.decode(self.send_buf))
                        print('----------------------------------------------------------------')
                    else:
                        print('################### send payload matched ######################')
                        print(PKT.decode(self.send_buf))
                        print('***************************************************************')
            else:
                if type(PKT.decode(msg)) == SUB_S_OPERATE_NOTIFY:
                    return msg
                else:
                    self.msgs.insert(0, msg)
                    return None
                    
    def send_message(self, buf):
        if type(PKT.decode(buf)) == HEAT_BEAT: return
        self.send_buf = buf

from websocket import create_connection,WebSocketTimeoutException
class WSGameConnection(GameConnection):
    def __init__(self):
        self.ws = create_connection("ws://73.hanyou.com:17301/")
    def send_message(self, buf):
        self.ws.send(buf)
    def get_message(self, timeout=None):
        try:
            self.ws.settimeout(timeout)
            return self.ws.recv()
        except WebSocketTimeoutException:
            return None
    def close(self):
        self.ws.close()
########################################
## ai part


weights = [10, 20, 30, 40, 50, 40, 30, 20, 10, 
          10, 20, 30, 40, 50, 40, 30, 20, 10, 
          10, 20, 30, 40, 50, 40, 30, 20, 10, 
          5, 5, 5, 5, 5, 5, 5, 5, 5, 3]

def discard_tile(hand, dead):
    rs = calculate_outs(hand, dead)
    rs.sort(key=lambda x:(-x['tiles_count'], weights[x['discard']]))
    return rs[0]

def should_op_tile(hand_orig, dead_orig, tile):
    hand = list(hand_orig)
    hand[34] += 1
    rs = calculate_outs(hand, dead_orig)
#     rs.sort(key=lambda x:(-x['tiles_count'], weights[x['discard']]))
    best_opt = None
    for opt in rs:
        if opt['discard'] == 34:
            best_opt = opt
    ret = None
#     print(best_opt)
    if hand[tile] >1 :
        hand = list(hand_orig)
        dead = list(dead_orig)
        hand[tile] -= 2
        dead[tile] += 3
        rs = calculate_outs(hand, dead)
        opt = rs[0]
#         print(opt)
        if opt['shanten'] < best_opt['shanten'] or opt['tiles_count'] > best_opt['tiles_count']:
            best_opt = opt
            ret = (tile, tile)
    if hand[tile+1] > 0 and hand[tile+2] > 0 and tile < 27 and (tile)//9 == (tile+2)//9:
        hand = list(hand_orig)
        dead = list(dead_orig)
        hand[tile+1] -= 1
        hand[tile+2] -= 1
        dead[tile] += 1
        dead[tile+1] += 1
        dead[tile+2] += 1
        rs = calculate_outs(hand, dead)
        opt = rs[0]
#         print(opt)
        if opt['shanten'] < best_opt['shanten'] or opt['tiles_count'] > best_opt['tiles_count']:
            best_opt = opt
            ret = (tile+1, tile+2)
    if hand[tile+1] > 0 and hand[tile-1] > 0 and tile < 27 and (tile+1)//9 == (tile-1)//9:
        hand = list(hand_orig)
        dead = list(dead_orig)
        hand[tile+1] -= 1
        hand[tile-1] -= 1
        dead[tile] += 1
        dead[tile+1] += 1
        dead[tile-1] += 1
        rs = calculate_outs(hand, dead)
        opt = rs[0]
#         print(opt)
        if opt['shanten'] < best_opt['shanten'] or opt['tiles_count'] > best_opt['tiles_count']:
            best_opt = opt
            ret = (tile-1, tile+1)
    if hand[tile-1] > 0 and hand[tile-2] > 0 and tile < 27 and (tile)//9 == (tile-2)//9:
        hand = list(hand_orig)
        dead = list(dead_orig)
        hand[tile-1] -= 1
        hand[tile-2] -= 1
        dead[tile] += 1
        dead[tile-1] += 1
        dead[tile-2] += 1
        rs = calculate_outs(hand, dead)
        opt = rs[0]
#         print(opt)
        if opt['shanten'] < best_opt['shanten'] or opt['tiles_count'] > best_opt['tiles_count']:
            best_opt = opt
            ret = (tile-2, tile-1)
    return ret
    

def calculate_outs(hand, dead):
    """
    hand: 34 array
    dead: 34 array
    """
    meld_num = 4 - sum(hand)//3
    results = []
#     print(hand, dead)
    hand_bak = list(hand)
    s_in = shanten(hand, meld_num)
#     print('--> s_in ', s_in)
    should_run_2 = False
    for k in (1, 2):
        for candi in range(35):
            if not hand[candi]:
                continue
            hand[candi] -= 1
            hand[34] += 1
            s = shanten(hand, meld_num)
            hand[34] -= 1
            if s > s_in and not should_run_2:
                hand[candi] += 1
                continue

            waiting = []
            tiles_count = 0
            for j in range(0, 35):
                if candi == j or hand[j] == 4:
                    continue
                hand[j] += 1
                if shanten(hand, meld_num) < s:
                    waiting.append(j)
    #                 print((4 - hand_bak[j] - dead[j]), TilesConverter.to_one_line_string([j*4]), hand_bak[j], dead[j], j)
                    tiles_count += (4 - hand_bak[j] - dead[j])
                hand[j] -= 1
            hand[candi] += 1

            if waiting:
                discard_opt = {'shanten':s, 'waiting':waiting, 'tiles_count':tiles_count, 'discard':candi}
                results.append(discard_opt)
        results.sort(key=lambda x:(x['shanten'], -x['tiles_count'], weights[x['discard']]))
        if results:
            if should_run_2:
                s = set(results[0]['waiting'])
                for i in results:
                    s = s.intersection(i['waiting'])
                if s:
                    t = s.pop()
                    if t in hand: 
#                         for i in results:
#                             print(i)
                        return [{'shanten':1, 'waiting':[], 'tiles_count':99, 'discard':t}]
            return results
        else:
            should_run_2 = True
    return results

# shanten = shanten_list


##########################################################################
## The Game Logic Part

import json, http.client, struct, os
from codes import *

def login(mac):
    conn = http.client.HTTPSConnection("web.hanyou.com")
    conn.request("GET", "/m/login_t.do?mac="+mac+"&state=%E4%B8%8A%E6%B5%B7&city=%E4%B8%8A%E6%B5%B7&lineid=100000")
    content = conn.getresponse().read()
    content = json.loads(content.decode('utf-8'))
    headers = {"Cookie":"JSESSIONID=%s"%content['sessionid'],"session_id":"%s"%content['sessionid'],
              "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 5.1.1; SM-N9005 Build/NJH47F)"}
    if content['score'] < 500:
        conn.request("POST", "/reloadGameMoney.do", '', headers)
        sync_ret = conn.getresponse().read()
        sync_ret = json.loads(sync_ret.decode('utf-8'))
        cprint(sync_ret, 'yellow')
    conn = http.client.HTTPConnection("web.hanyou.com")
    conn.request("POST", "/login/synconline.do?gid=73&sid=17301", '', headers)
    sync_ret = conn.getresponse().read()
    sync_ret = json.loads(sync_ret.decode('utf-8'))
    return content

# login('ffffffff-b319-4c6f-ffff-ffffa7b1fa34')

from termcolor import colored, cprint
class VGame():
    def __init__(self):
        self.hand = []
        self.me_out_list = []
        self.enemy_out_list = []
        self.double = 0
    def me_out(self, tile):
        if tile >= 0x35 and tile <= 0x37: self.double += 1
        self.me_out_list.append(tile)
        self.hand.remove(tile)
        print('==========> We out ', CARDS[tile])
        self.print_myhand()
    def me_worst_tile(self):
        t = None
        aux = ''
        if 0x35 in self.hand:
            t = 0x35
        if 0x36 in self.hand:
            t = 0x36
        if 0x37 in self.hand:
            t = 0x37
        if not t:
            self.print_myhand()
            print(list_to_34(self.hand))
            do = discard_tile(list_to_34(self.hand), list_to_34(self.me_out_list+self.enemy_out_list))
            t = tile_from_34[do['discard']]
            w = '|'.join([CARDS[tile_from_34[i]] for i in do['waiting']])
            aux = '    shanten[%d]  waiting[%s]' % (do['shanten'], w)
        cprint('##############=============> We suggest %s times[%d] %s' % (CARDS[t], 2**self.double, aux), 'green')
        return t
    def enemy_out(self, tile):
        if tile >= 0x35 and tile <= 0x37: self.double += 1
        self.enemy_out_list.append(tile)
        print('==========> They out ', CARDS[tile])
    def me_init_hand(self, tiles):
        self.hand = tiles
    def me_draw_tile(self, tile):
        self.hand.append(tile)
        print('==========> We draw ', CARDS[tile])
    def operate_tile(self, tile, mask):
        opt = should_op_tile(list_to_34(self.hand), list_to_34(self.me_out_list+self.enemy_out_list), tile_to_34[tile])
        if opt:
            t1, t2 = [tile_from_34[i] for i in opt]
            rs = [t1, t2, tile]
            rs.sort()
            rs = [CARDS[i] for i in rs]
            cprint('##############=============> We suggest '+ ''.join(rs), 'green')
            d = tile - t1
            if d == 0:
                return WIK_PENG
            elif d == -1:
                return WIK_LEFT
            elif d == 1:
                return WIK_CENTER
            elif d == 2:
                return WIK_RIGHT
        else:
            cprint('##############=============> We suggest 过', 'green')
            return 0
    def print_myhand(self):
        self.hand.sort()
        ret = ''
        for i in self.hand:
            ret += CARDS[i]+'|'
        print('=======> my hand: ', ret)
    def no_op(self):
        cprint('##############=============> We suggest 过', 'green')
    def chi_hu(self):
        cprint('##############=============> We suggest 胡', 'green')
    def zi_mo(self):
        cprint('##############=============> We suggest 自摸', 'green')
        
def play_game(mac=None, filename=None, live=False):
    if mac:
        conn = WSGameConnection()
        c = login(mac) ## login('ffffffff-e184-87b9-ffff-ffffa7b1fa34')
        userID, pwd = int(c['userId']), c['pwd']
    else:
        conn = PcapGameConnection(filename=filename, live=live)
        userID, pwd = 123, 'password'
    login_pkt = SUB_GS_LOGON_USERID(userID, pwd)
    conn.send_message(login_pkt.ser())
    me_id = 0
    medal_task = 0; print_medal = False
    while True:
        msg = conn.get_message()
        print('==> ', msg)
        msg = PKT.decode(msg)
        print(msg)
        if type(msg) == SUB_GS_USER_SCORE:
            me_id = msg.dwUserID
            print('login done')
            break
#     return
    def join_table():
        # go_together()
        print('gogogo')
        conn.send_message(SUB_GS_USER_JOIN_RANDOM_LIST_SYN().ser())
    join_table()
    me_chair = -1
    g = None
    def out_card():
        print('^^^^^^^^^^^^^^--> ', SUB_C_OUT_CARD(t))
        t = g.me_worst_tile()
        conn.send_message(SUB_C_OUT_CARD(t).ser())
    while True:
        msg = conn.get_message()
        msg = PKT.decode(msg)
        print(msg)
        if type(msg) == SUB_S_START_SEND_CARD:
            g = VGame()
            g.me_init_hand(msg.tiles)
            if msg.wBankerUser == me_chair:
                out_card()
            else:
                g.hand.remove(0)
        elif type(msg) == HEAT_BEAT:
            conn.send_message(msg.ser())  # send it back
        elif type(msg) == SUB_S_OUT_CARD:
            if me_chair == msg.user:
                g.me_out(msg.tile)
            else:
                g.enemy_out(msg.tile)
        elif type(msg) == SUB_GS_USER_STATUS:
            if me_id == msg.userID:
                me_chair = msg.chairID
                if msg.status == 1:
                    if os.path.exists('stop'): break
                    join_table()
                if msg.status == 2:
                    conn.send_message(SUB_GS_INFO().ser())
        elif type(msg) == SUB_S_SEND_CARD:
            if me_chair == msg.user:
                g.me_draw_tile(msg.tile)
                t = g.me_worst_tile()
                msg = conn.get_message(timeout=0.03)
                need_out_card = True
                if msg: 
                    msg = PKT.decode(msg)
                    if type(msg) == SUB_S_OPERATE_NOTIFY:
                        print(msg)
                        m = msg.cbActionMask
                        t = msg.cbActionCard
                        op = SUB_C_OPERATE_CARD()
                        op.tile = t
                        if m & WIK_CHI_HU:
                            g.chi_hu()
                            op.action = WIK_CHI_HU
                            need_out_card = False
                        elif m & WIK_ZI_MO:
                            g.zi_mo()
                            op.action = WIK_ZI_MO
                            need_out_card = False
                        elif m & WIK_GANG:
                            g.no_op()
                            op.action = 0
                            op.tile = 0
                        conn.send_message(op.ser())
                if need_out_card:
                    print('^^^^^^^^^^^^^^2--> ', SUB_C_OUT_CARD(t))
                    conn.send_message(SUB_C_OUT_CARD(t).ser())
        elif type(msg) == SUB_S_OPERATE_NOTIFY:
            m = msg.cbActionMask
            t = msg.cbActionCard
            op = SUB_C_OPERATE_CARD()
            op.tile = t
            actions = WIK_LEFT | WIK_CENTER | WIK_RIGHT | WIK_PENG
            if m & WIK_CHI_HU:
                g.chi_hu()
                op.action = WIK_CHI_HU
            elif m & WIK_ZI_MO:
                g.zi_mo()
                op.action = WIK_ZI_MO
            elif actions & m:
                op.action = g.operate_tile(t, m)
                if op.action == 0: op.tile = 0
            elif m & WIK_GANG:
                g.no_op()
                op.action = 0
                op.tile = 0
            conn.send_message(op.ser())
        elif type(msg) == SUB_S_OPERATE_RESULT:
            cbOperateCode = msg.cbOperateCode
            cbOperateCard = msg.cbOperateCard
            if cbOperateCode:
                cards = []
                if cbOperateCode == WIK_LEFT:
                    cards = [cbOperateCard+1, cbOperateCard+2]
                elif cbOperateCode == WIK_CENTER:
                    cards = [cbOperateCard-1, cbOperateCard+1] 
                elif cbOperateCode == WIK_RIGHT:
                    cards = [cbOperateCard-2, cbOperateCard-1] 
                elif cbOperateCode == WIK_PENG:
                    cards = [cbOperateCard, cbOperateCard] 
                elif cbOperateCode == WIK_GANG:
                    cards = [cbOperateCard, cbOperateCard, cbOperateCard]
                if msg.wOperateUser == me_chair:
                    for i in cards:
                        g.me_out(i)
                    out_card()
            else:
                if len(g.hand) % 3 == 2:  # when we can zi_mo but we choose not to
                    out_card()
        elif type(msg) == SUB_S_GAME_END:
            txt = 'GameScore[%d] WinTimes[%d]'%(msg.lGameScore[me_chair], msg.lWinTimes[me_chair])
            cprint(txt, 'green')
        elif type(msg) == SUB_GS_USER_SCORE and msg.dwUserID == me_id:
            txt = 'MyScore[%d] WinLostRate[%d/%d]'%(msg.lScore, msg.lWinCount, msg.lLostCount)
            cprint(txt, 'green')
        elif type(msg) == SUB_GS_USER_TASK_INFO:
            for i in msg.task_infos:
                if i['eRewardsType'] == 2 and i['bIsFinished']:
                    medal_task += i['RewardsNums']
            txt = 'Medals[%d]' % medal_task
            if print_medal: 
                cprint(txt, 'green')
            print_medal = not print_medal
    conn.close()

####################################################################
## redis part

from redis import StrictRedis
def go_together():
    redis = StrictRedis(host='localhost', port=6379)
    ps = redis.pubsub()
    ps.subscribe('c1')
    l = ps.listen()
    for m in l:
        if m['type'] == 'message':
            break
    redis = None

    
    
import sys

#play_game(filename = '/tmp/0605.pcap')
play_game(filename = '/tmp/h17301.pcap')


mac = 'ffffffff-e184-87ba-ffff-ffffa7b1fa34'
if len(sys.argv) > 1:
    mac = sys.argv[1]

#play_game(live=True)

