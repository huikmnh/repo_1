codes = {'HEAD_SIZE': '8',
 'MAIN_GS_FRAME': '12464',
 'MAIN_GS_GAME': '12448',
 'MAIN_GS_INFO': '12368',
 'MAIN_GS_LOGON': '12304',
 'MAIN_GS_SERVER_INFO': '12432',
 'MAIN_GS_SPEAKER': '12480',
 'MAIN_GS_STATUS': '12384',
 'MAIN_GS_SYSTEM': '12416',
 'MAIN_GS_USER': '12320',
 'MATCH_MAIN_CMD': '8202',
 'OPCODE_CLIENT_BACK_ANNINFO_ACK': '1449994',
 'OPCODE_CLIENT_ENTER_ACK': '139274',
 'OPCODE_CLIENT_ENTER_GAME_ACK': '1515530',
 'OPCODE_CLIENT_ENTER_SYN': '73738',
 'OPCODE_CLIENT_EXIT_GAME_ACK': '1581066',
 'OPCODE_CLIENT_GET_ANNINFO_ACK': '1384458',
 'OPCODE_CLIENT_GET_ANNINFO_SYN': '1318922',
 'OPCODE_CLIENT_GET_FREESERVER_ACK': '1187850',
 'OPCODE_CLIENT_GET_MATCH_INFO_SYN': '860170',
 'OPCODE_CLIENT_GET_MATCH_STATUS_INFO_ACK': '991242',
 'OPCODE_CLIENT_GET_MATCH_STATUS_INFO_SYN': '925706',
 'OPCODE_CLIENT_GET_SERVER_ACK': '663562',
 'OPCODE_CLIENT_GET_SERVER_SYN': '598026',
 'OPCODE_CLIENT_GET_SIGN_NUM_ACK': '794634',
 'OPCODE_CLIENT_GET_SIGN_NUM_SYN': '729098',
 'OPCODE_CLIENT_MATCH_CONFIG_CMD': '5251082',
 'OPCODE_CLIENT_MATCH_INFO_CMD': '532490',
 'OPCODE_CLIENT_PROCESS_FAILED': '6553610',
 'OPCODE_CLIENT_REBUYING_CMD': '1646602',
 'OPCODE_CLIENT_REWARDPOOL_SCORE_ACK': '2301962',
 'OPCODE_CLIENT_REWARDPOOL_SCORE_SYN': '2236426',
 'OPCODE_CLIENT_SIGN_ACK': '270346',
 'OPCODE_CLIENT_SIGN_CMD': '466954',
 'OPCODE_CLIENT_SIGN_SYN': '204810',
 'OPCODE_CLIENT_TOUR_CHAMPION_INFO_ACK': '4464650',
 'OPCODE_CLIENT_TOUR_CHAMPION_INFO_SYN': '4399114',
 'OPCODE_CLIENT_TOUR_MY_HISTORY_ACK': '4726794',
 'OPCODE_CLIENT_TOUR_MY_HISTORY_SYN': '4661258',
 'OPCODE_CLIENT_TOUR_PROGRESS_INFO_ACK': '4333578',
 'OPCODE_CLIENT_TOUR_PROGRESS_INFO_SYN': '4268042',
 'OPCODE_CLIENT_TOUR_QUITMATCH_ACK': '3678218',
 'OPCODE_CLIENT_TOUR_QUITMATCH_SYN': '3612682',
 'OPCODE_CLIENT_TOUR_RANKLIST_ACK': '3416074',
 'OPCODE_CLIENT_TOUR_RANKLIST_SYN': '3350538',
 'OPCODE_CLIENT_TOUR_READY_PLAY_ACK': '3285002',
 'OPCODE_CLIENT_TOUR_READY_PLAY_SYN': '3219466',
 'OPCODE_CLIENT_TOUR_STATUS_CHANGE_CMD': '4792330',
 'OPCODE_CLIENT_TOUR_UNREADY_PLAY_ACK': '4595722',
 'OPCODE_CLIENT_TOUR_UNREADY_PLAY_SYN': '4530186',
 'OPCODE_CLIENT_TOUR_USERTOP_SUM_ACK': '4202506',
 'OPCODE_CLIENT_TOUR_USERTOP_SUM_SYN': '3743754',
 'OPCODE_CLIENT_UNSIGN_ACK': '401418',
 'OPCODE_CLIENT_UNSIGN_SYN': '335882',
 'OPCODE_CLIENT_USER_BESTINFO_ACK': '1122314',
 'OPCODE_CLIENT_USER_BESTINFO_SYN': '1056778',
 'OPCODE_CLIENT_WAIT_REBUYING_ACK': '2105354',
 'OPCODE_PING': '65536',
 'OPCODE_REBUYED_ACK': '2170890',
 'SUBID_OPCODE_CLIENT_GET_MATCH_INFO_SYN': '13',
 'SUBID_OPCODE_CLIENT_GET_SERVER_ACK': '10',
 'SUBID_OPCODE_CLIENT_GET_SERVER_SYN': '9',
 'SUBID_OPCODE_CLIENT_GET_SIGN_NUM_ACK': '12',
 'SUBID_OPCODE_CLIENT_GET_SIGN_NUM_SYN': '11',
 'SUBID_OPCODE_CLIENT_MATCH_INFO_CMD': '8',
 'SUBID_OPCODE_CLIENT_REBUYING_CMD': '25',
 'SUBID_OPCODE_CLIENT_REWARDPOOL_SCORE_ACK': '35',
 'SUBID_OPCODE_CLIENT_REWARDPOOL_SCORE_SYN': '34',
 'SUBID_OPCODE_CLIENT_TOUR_CHAMPION_INFO_ACK': '68',
 'SUBID_OPCODE_CLIENT_TOUR_CHAMPION_INFO_SYN': '67',
 'SUBID_OPCODE_CLIENT_TOUR_MY_HISTORY_ACK': '72',
 'SUBID_OPCODE_CLIENT_TOUR_MY_HISTORY_SYN': '71',
 'SUBID_OPCODE_CLIENT_TOUR_PROGRESS_INFO_ACK': '66',
 'SUBID_OPCODE_CLIENT_TOUR_PROGRESS_INFO_SYN': '65',
 'SUBID_OPCODE_CLIENT_TOUR_QUITMATCH_ACK': '56',
 'SUBID_OPCODE_CLIENT_TOUR_QUITMATCH_SYN': '55',
 'SUBID_OPCODE_CLIENT_TOUR_RANKLIST_ACK': '52',
 'SUBID_OPCODE_CLIENT_TOUR_RANKLIST_SYN': '51',
 'SUBID_OPCODE_CLIENT_TOUR_READY_PLAY_ACK': '50',
 'SUBID_OPCODE_CLIENT_TOUR_READY_PLAY_SYN': '49',
 'SUBID_OPCODE_CLIENT_TOUR_UNREADY_PLAY_ACK': '70',
 'SUBID_OPCODE_CLIENT_TOUR_UNREADY_PLAY_SYN': '69',
 'SUBID_OPCODE_CLIENT_TOUR_USERTOP_SUM_ACK': '64',
 'SUBID_OPCODE_CLIENT_TOUR_USERTOP_SUM_SYN': '57',
 'SUBID_OPCODE_CLIENT_UNSIGN_ACK': '6',
 'SUBID_OPCODE_CLIENT_WAIT_REBUYING_ACK': '32',
 'SUBID_OPCODE_REBUYED_ACK': '33',
 'SUB_GS_ALL_USER_READY': '12375',
 'SUB_GS_BANK_LOGLIST': '12353',
 'SUB_GS_BANK_LOGON': '12343',
 'SUB_GS_BANK_LOGON_FAIL': '12345',
 'SUB_GS_BANK_LOGON_SUCCESS': '12344',
 'SUB_GS_BANK_MODIFY_PWD': '12354',
 'SUB_GS_BANK_MODIFY_PWD_FAIL': '12356',
 'SUB_GS_BANK_MODIFY_PWD_SUCCESS': '12355',
 'SUB_GS_BANK_REGISTER': '12346',
 'SUB_GS_BANK_REGISTER_FAIL': '12348',
 'SUB_GS_BANK_REGISTER_SUCCESS': '12347',
 'SUB_GS_BANK_TRADE': '12349',
 'SUB_GS_BANK_TRADE_FAIL': '12351',
 'SUB_GS_BANK_TRADE_SUCCESS': '12350',
 'SUB_GS_BANK_TRANSFER_RECEIVE': '12352',
 'SUB_GS_COLUMN_INFO': '12372',
 'SUB_GS_CONFIG_FINISH': '12373',
 'SUB_GS_CRACKEGG_CHANCE': '12340',
 'SUB_GS_CRACKEGG_DOIT': '12342',
 'SUB_GS_GAMESETTING': '12455',
 'SUB_GS_GAME_ACT_CALC_CMD': '12494',
 'SUB_GS_GAME_ACT_RELOGON_CMD': '12495',
 'SUB_GS_GAME_ACT_TOPTEN_CMD': '12493',
 'SUB_GS_GAME_DADISHU_HIT_REQ': '12417',
 'SUB_GS_GAME_DADISHU_HIT_RES': '12418',
 'SUB_GS_GAME_DADISHU_INFO': '12416',
 'SUB_GS_GAME_RANK_LAST_LIST': '12497',
 'SUB_GS_GAME_RANK_REWARD_INFO': '12498',
 'SUB_GS_GAME_RANK_TOPLIST': '12496',
 'SUB_GS_GETROOM_INFO': '12311',
 'SUB_GS_GOLD_PERCOUNT': '12339',
 'SUB_GS_INFO': '12449',
 'SUB_GS_LOGON_ACCOUNTS': '12305',
 'SUB_GS_LOGON_FAIL': '12308',
 'SUB_GS_LOGON_FINISH': '12309',
 'SUB_GS_LOGON_SUCCESS': '12307',
 'SUB_GS_LOGON_USERID': '12306',
 'SUB_GS_LOGON_USERID_MOBILE': '12310',
 'SUB_GS_MAIL_GET_NEW_COUNT': '12357',
 'SUB_GS_MAIL_GET_NEW_COUNT_FAIL': '12358',
 'SUB_GS_MAIL_GET_NEW_COUNT_SUCCESS': '12359',
 'SUB_GS_MATCH_GET_USERLIST': '12401',
 'SUB_GS_MATCH_TIME_OUT': '12400',
 'SUB_GS_MEMBER_INFO': '12371',
 'SUB_GS_MESSAGE': '12454',
 'SUB_GS_ONLINE_CNT_INFO': '12433',
 'SUB_GS_OPTION': '12451',
 'SUB_GS_ORDER_INFO': '12370',
 'SUB_GS_REDIRECT_CMD': '12312',
 'SUB_GS_ROOM_INFO': '12387',
 'SUB_GS_SCENE': '12452',
 'SUB_GS_SERVER_INFO': '12369',
 'SUB_GS_SYSMESSAGE': '12417',
 'SUB_GS_TABLE_INFO': '12385',
 'SUB_GS_TABLE_STATUS': '12386',
 'SUB_GS_USER_BANNEDMESSAGE': '12371',
 'SUB_GS_USER_BANNED_INFO': '12374',
 'SUB_GS_USER_BANNED_INFO_SPEAKER': '12385',
 'SUB_GS_USER_BANNED_STATUS': '12373',
 'SUB_GS_USER_CANCELMESSAGE': '12372',
 'SUB_GS_USER_CHAT_INGAME': '12453',
 'SUB_GS_USER_CHAT_INROOM': '12329',
 'SUB_GS_USER_COME': '12325',
 'SUB_GS_USER_COME_WEIQI': '12337',
 'SUB_GS_USER_EXIT': '12456',
 'SUB_GS_USER_FAIND_FRIEND_TABLE_REQ': '12403',
 'SUB_GS_USER_GETMONEY': '12334',
 'SUB_GS_USER_GIFT_INFO': '12403',
 'SUB_GS_USER_GIFT_REQ': '12404',
 'SUB_GS_USER_GIFT_RESULT': '12405',
 'SUB_GS_USER_INVITE': '12332',
 'SUB_GS_USER_INVITE_REQ': '12333',
 'SUB_GS_USER_JOIN_BUTTON_STATUS_CMD': '12433',
 'SUB_GS_USER_JOIN_RANDOM_LIST_SYN': '12432',
 'SUB_GS_USER_LEFT_GAME_REQ': '12324',
 'SUB_GS_USER_LOOKON_REQ': '12322',
 'SUB_GS_USER_LOTTERY_CNT': '12341',
 'SUB_GS_USER_MATCH_COIN': '12370',
 'SUB_GS_USER_MATCH_SIGNUP_REQ': '12402',
 'SUB_GS_USER_MATCH_STATUS': '12367',
 'SUB_GS_USER_OUT': '12336',
 'SUB_GS_USER_PROPERTY': '12335',
 'SUB_GS_USER_QUICT_SIT_REQ': '12402',
 'SUB_GS_USER_READY': '12450',
 'SUB_GS_USER_REPUEST': '12366',
 'SUB_GS_USER_RULE': '12331',
 'SUB_GS_USER_SCORE': '12327',
 'SUB_GS_USER_SIT_FAILED': '12328',
 'SUB_GS_USER_SIT_REQ': '12321',
 'SUB_GS_USER_SIT_TIPS': '12369',
 'SUB_GS_USER_STANDUP_REQ': '12323',
 'SUB_GS_USER_STATUS': '12326',
 'SUB_GS_USER_STATUS_TOOS': '12368',
 'SUB_GS_USER_TASK_INFO': '12419',
 'SUB_GS_USER_TASK_STATUS': '12420',
 'SUB_GS_USER_WELFARISM_TIME': '12338',
 'SUB_GS_USER_WISPER': '12330',
 'VERSION': '69',
 'VERSION_MATCH': '68',
'SUB_S_GAME_START' : '100',
'SUB_S_OUT_CARD' : '101',
'SUB_S_SEND_CARD' : '102',
'SUB_S_LISTEN_CARD' : '103',
'SUB_S_OPERATE_NOTIFY' : '104',
'SUB_S_OPERATE_RESULT' : '105',
'SUB_S_GAME_END' : '106',
'SUB_S_TRUSTEE' : '107',
'SUB_S_HAI_DI_LAO' : '108',
'SUB_S_START_SEND_CARD' : '109',
'SUB_S_SET_SCORE' : '112',
'GUESS_HEART_BEAT' : 0,
         
        'SUB_C_OUT_CARD' : 1,
        'SUB_C_LISTEN_CARD' : 2,
        'SUB_C_OPERATE_CARD' : 3,
        'SUB_C_TRUSTEE' : 4,
        'SUB_C_HAI_DI_CARD' : 5,
        'SUB_C_CUO_HUAN_CARD' : 6,
        'SUB_C_START_HUAN_CARD' : 7
}

codes_c2n = {i:int(codes[i]) for i in codes}

WIK_LEFT = 0x01;
WIK_CENTER = 0x02;
WIK_RIGHT = 0x04;
WIK_PENG = 0x08;
WIK_GANG = 0x10;
WIK_LISTEN = 0x20;
WIK_CHI_HU = 0x40;
WIK_ZI_MO = 0x80;

codes = {int(codes[i]):i for i in codes}

CARDS = {
            0x01:'1条', 0x02:'2条', 0x03:'3条', 0x04:'4条', 0x05:'5条', 0x06:'6条', 0x07:'7条', 0x08:'8条', 0x09:'9条',
            0x11:'1万', 0x12:'2万', 0x13:'3万', 0x14:'4万', 0x15:'5万', 0x16:'6万', 0x17:'7万', 0x18:'8万', 0x19:'9万',
            0x21:'1筒', 0x22:'2筒', 0x23:'3筒', 0x24:'4筒', 0x25:'5筒', 0x26:'6筒', 0x27:'7筒', 0x28:'8筒', 0x29:'9筒',
            0x31:'东', 0x32:'南', 0x33:'西', 0x34:'北', 0x35:'中', 0x36:'发', 0x37:'白', 0x38:'混', 0x00:'未知'
    
};

tile_to_34 = {
            0x01:18, 0x02:19, 0x03:20, 0x04:21, 0x05:22, 0x06:23, 0x07:24, 0x08:25, 0x09:26,
            0x11:0, 0x12:1, 0x13:2, 0x14:3, 0x15:4, 0x16:5, 0x17:6, 0x18:7, 0x19:8,
            0x21:9, 0x22:10, 0x23:11, 0x24:12, 0x25:13, 0x26:14, 0x27:15, 0x28:16, 0x29:17,
            0x31:27, 0x32:28, 0x33:29, 0x34:30
    
};

tile_from_34 = {tile_to_34[i]:i for i in tile_to_34}

def list_to_34(tiles):
    ret = [0]*35
    for i in tiles:
        if i in tile_to_34:
            ret[tile_to_34[i]] += 1
    return ret



#########################################################
# -*- coding: utf-8 -*-
import math

import copy

# from mahjong.utils import find_isolated_tile_indices


class Shanten(object):
    AGARI_STATE = -1

    tiles = []
    number_melds = 0
    number_tatsu = 0
    number_pairs = 0
    number_jidahai = 0
    number_characters = 0
    number_isolated_tiles = 0
    min_shanten = 0

    def calculate_shanten(self, tiles_34, open_sets_34=None):
        """
        Return the count of tiles before tempai
        :param tiles_34: 34 tiles format array
        :param open_sets_34: array of array of 34 tiles format
        :return: int
        """
        # we will modify them later, so we need to use a copy
        tiles_34 = copy.deepcopy(tiles_34)

        self._init(tiles_34)

        count_of_tiles = sum(tiles_34)

        if count_of_tiles > 14:
            return -2

#         # With open hand we need to remove open sets from hand and replace them with isolated pon sets
#         # it will allow to calculate count of shanten correctly
#         if open_sets_34:
#             isolated_tiles = find_isolated_tile_indices(tiles_34)
#             for meld in open_sets_34:
#                 if not isolated_tiles:
#                     break

#                 isolated_tile = isolated_tiles.pop()

#                 tiles_34[meld[0]] -= 1
#                 tiles_34[meld[1]] -= 1
#                 tiles_34[meld[2]] -= 1
#                 tiles_34[isolated_tile] = 3

#         if not open_sets_34:
        #self.min_shanten = self._scan_chitoitsu_and_kokushi()

        self._remove_character_tiles(count_of_tiles)

        init_mentsu = math.floor((14 - count_of_tiles) / 3)
        
        self.i_m = init_mentsu
        
#         self._scan(init_mentsu)
        self._scan(0)

        return self.min_shanten

    def _init(self, tiles):
        self.tiles = tiles
        self.number_melds = 0
        self.number_tatsu = 0
        self.number_pairs = 0
        self.number_jidahai = 0
        self.number_characters = 0
        self.number_isolated_tiles = 0
        self.min_shanten = 8

    def _scan(self, init_mentsu):
        self.number_characters = 0
        for i in range(0, 27):
            self.number_characters |= (self.tiles[i] == 4) << i
        self.number_melds += init_mentsu
        self._run(0)

    def _run(self, depth):
        if self.min_shanten == Shanten.AGARI_STATE:
            return

        while not self.tiles[depth]:
            depth += 1

            if depth >= 27:
                break

        if depth >= 27:
            return self._update_result()

        i = depth
        if i > 8:
            i -= 9
        if i > 8:
            i -= 9

        if self.tiles[depth] == 4:
            self._increase_set(depth)
            if i < 7 and self.tiles[depth + 2]:
                if self.tiles[depth + 1]:
                    self._increase_syuntsu(depth)
                    self._run(depth + 1)
                    self._decrease_syuntsu(depth)
                self._increase_tatsu_second(depth)
                self._run(depth + 1)
                self._decrease_tatsu_second(depth)

            if i < 8 and self.tiles[depth + 1]:
                self._increase_tatsu_first(depth)
                self._run(depth + 1)
                self._decrease_tatsu_first(depth)

            self._increase_isolated_tile(depth)
            self._run(depth + 1)
            self._decrease_isolated_tile(depth)
            self._decrease_set(depth)
            self._increase_pair(depth)

            if i < 7 and self.tiles[depth + 2]:
                if self.tiles[depth + 1]:
                    self._increase_syuntsu(depth)
                    self._run(depth)
                    self._decrease_syuntsu(depth)
                self._increase_tatsu_second(depth)
                self._run(depth + 1)
                self._decrease_tatsu_second(depth)

            if i < 8 and self.tiles[depth + 1]:
                self._increase_tatsu_first(depth)
                self._run(depth + 1)
                self._decrease_tatsu_first(depth)

            self._decrease_pair(depth)

        if self.tiles[depth] == 3:
            self._increase_set(depth)
            self._run(depth + 1)
            self._decrease_set(depth)
            self._increase_pair(depth)

            if i < 7 and self.tiles[depth + 1] and self.tiles[depth + 2]:
                self._increase_syuntsu(depth)
                self._run(depth + 1)
                self._decrease_syuntsu(depth)
            else:
                if i < 7 and self.tiles[depth + 2]:
                    self._increase_tatsu_second(depth)
                    self._run(depth + 1)
                    self._decrease_tatsu_second(depth)

                if i < 8 and self.tiles[depth + 1]:
                    self._increase_tatsu_first(depth)
                    self._run(depth + 1)
                    self._decrease_tatsu_first(depth)

            self._decrease_pair(depth)

            if i < 7 and self.tiles[depth + 2] >= 2 and self.tiles[depth + 1] >= 2:
                self._increase_syuntsu(depth)
                self._increase_syuntsu(depth)
                self._run(depth)
                self._decrease_syuntsu(depth)
                self._decrease_syuntsu(depth)

        if self.tiles[depth] == 2:
            self._increase_pair(depth)
            self._run(depth + 1)
            self._decrease_pair(depth)
            if i < 7 and self.tiles[depth + 2] and self.tiles[depth + 1]:
                self._increase_syuntsu(depth)
                self._run(depth)
                self._decrease_syuntsu(depth)

        if self.tiles[depth] == 1:
            if i < 6 and self.tiles[depth + 1] == 1 and self.tiles[depth + 2] and self.tiles[depth + 3] != 4:
                self._increase_syuntsu(depth)
                self._run(depth + 2)
                self._decrease_syuntsu(depth)
            else:
                self._increase_isolated_tile(depth)
                self._run(depth + 1)
                self._decrease_isolated_tile(depth)

                if i < 7 and self.tiles[depth + 2]:
                    if self.tiles[depth + 1]:
                        self._increase_syuntsu(depth)
                        self._run(depth + 1)
                        self._decrease_syuntsu(depth)
                    self._increase_tatsu_second(depth)
                    self._run(depth + 1)
                    self._decrease_tatsu_second(depth)

                if i < 8 and self.tiles[depth + 1]:
                    self._increase_tatsu_first(depth)
                    self._run(depth + 1)
                    self._decrease_tatsu_first(depth)

    def _update_result(self):
#         print(self.number_melds  , self.i_m , self.number_tatsu,self.number_pairs)
        ret_shanten = 8 - self.number_melds * 2 - self.i_m*2 - self.number_tatsu - self.number_pairs
        n_mentsu_kouho = self.number_melds + self.number_tatsu + self.i_m
        if self.number_pairs:
            n_mentsu_kouho += self.number_pairs - 1
        elif self.number_characters and self.number_isolated_tiles:
            if (self.number_characters | self.number_isolated_tiles) == self.number_characters:
                ret_shanten += 1

        if n_mentsu_kouho > 4:
            ret_shanten += n_mentsu_kouho - 4

        if ret_shanten != Shanten.AGARI_STATE and ret_shanten < self.number_jidahai:
            ret_shanten = self.number_jidahai

        if ret_shanten < self.min_shanten:
            self.min_shanten = ret_shanten

    def _increase_set(self, k):
#         print('1111111111')
        self.tiles[k] -= 3
        self.number_melds += 1

    def _decrease_set(self, k):
        self.tiles[k] += 3
        self.number_melds -= 1

    def _increase_pair(self, k):
        self.tiles[k] -= 2
        self.number_pairs += 1

    def _decrease_pair(self, k):
        self.tiles[k] += 2
        self.number_pairs -= 1

    def _increase_syuntsu(self, k):
#         print('2222222222222')
        self.tiles[k] -= 1
        self.tiles[k + 1] -= 1
        self.tiles[k + 2] -= 1
        self.number_melds += 1

    def _decrease_syuntsu(self, k):
        self.tiles[k] += 1
        self.tiles[k + 1] += 1
        self.tiles[k + 2] += 1
        self.number_melds -= 1

    def _increase_tatsu_first(self, k):
        self.tiles[k] -= 1
        self.tiles[k + 1] -= 1
        self.number_tatsu += 1

    def _decrease_tatsu_first(self, k):
        self.tiles[k] += 1
        self.tiles[k + 1] += 1
        self.number_tatsu -= 1

    def _increase_tatsu_second(self, k):
        self.tiles[k] -= 1
        self.tiles[k + 2] -= 1
        self.number_tatsu += 1

    def _decrease_tatsu_second(self, k):
        self.tiles[k] += 1
        self.tiles[k + 2] += 1
        self.number_tatsu -= 1

    def _increase_isolated_tile(self, k):
        self.tiles[k] -= 1
        self.number_isolated_tiles |= (1 << k)

    def _decrease_isolated_tile(self, k):
        self.tiles[k] += 1
        self.number_isolated_tiles |= (1 << k)

    def _scan_chitoitsu_and_kokushi(self):
        shanten = self.min_shanten

        indices = [0, 8, 9, 17, 18, 26, 27, 28, 29, 30, 31, 32, 33]

        completed_terminals = 0
        for i in indices:
            completed_terminals += self.tiles[i] >= 2

        terminals = 0
        for i in indices:
            terminals += self.tiles[i] != 0

        indices = [1, 2, 3, 4, 5, 6, 7, 10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25]

        completed_pairs = completed_terminals
        for i in indices:
            completed_pairs += self.tiles[i] >= 2

        pairs = terminals
        for i in indices:
            pairs += self.tiles[i] != 0

        ret_shanten = 6 - completed_pairs + (pairs < 7 and 7 - pairs or 0)
        if ret_shanten < shanten:
            shanten = ret_shanten

        ret_shanten = 13 - terminals - (completed_terminals and 1 or 0)
        if ret_shanten < shanten:
            shanten = ret_shanten

        return shanten

    def _remove_character_tiles(self, nc):
        number = 0
        isolated = 0

        for i in range(27, 35):
            if self.tiles[i] == 4:
                self.number_melds += 1
                self.number_jidahai += 1
                number |= (1 << (i - 27))
                isolated |= (1 << (i - 27))

            if self.tiles[i] == 3:
                self.number_melds += 1

            if self.tiles[i] == 2:
                self.number_pairs += 1

            if self.tiles[i] == 1:
                isolated |= (1 << (i - 27))

        if self.number_jidahai and (nc % 3) == 2:
            self.number_jidahai -= 1

        if isolated:
            self.number_isolated_tiles |= (1 << 27)
            if (number | isolated) == number:
                self.number_characters |= (1 << 27)

S = Shanten()
shanten = S.calculate_shanten

## some common routines

import struct

def read_str(buff):
    n = buff.find(b'\x00')
    return buff[0:n].decode('gbk'), n

def unmask_payload(data, masks):
    ret = b''
    for i in range(len(data)):
        ret += struct.pack('B', ord(data[i:i+1])^ord(masks[i%4:i%4+1]))
    return ret


###############################################################
## the message formats

import inspect

class PKT():
    reg = {}
    def ser(self):
        payload = self.body()
        frame_len = len(payload) + 8
        header = struct.pack('HBbHH', frame_len, 0, 69, self.main, self.sub)
        return header+payload
    def body(self):
        return b''
    def decode_body(self, buf):
        pass
    def __repr__(self):
        atts = {}
        for i in dir(self):
            if i[0] == '_' or i in ('main', 'sub', 'reg'):
                continue
            att = self.__getattribute__(i)
            if inspect.ismethod(att):
                continue
            atts[i] = att
#         print(type(atts))
#         print(atts.keys())
#         return 'gogogo'
        return '%s ==> %s'%(self._t,atts.__repr__())
    
    @classmethod
    def register(cls, msg_type):
        cls.reg[(msg_type.main, msg_type.sub)] = msg_type
    
    @classmethod
    def decode(cls, buf):
        frame_len, check_code, v, cmd_main, cmd_sub = struct.unpack('HBbHH', buf[:8])
        if (cmd_main, cmd_sub) in cls.reg:
            msg_type = cls.reg[(cmd_main, cmd_sub)]
            msg = msg_type()
            msg.decode_body(buf[8:])
        else:
            msg = cls()
            msg.main = cmd_main
            msg.sub = cmd_sub
            msg._t = '%s|%s'%(codes[cmd_main] if cmd_main in codes else cmd_main,codes[cmd_sub] if cmd_sub in codes else cmd_sub)
        msg.body_len = len(buf)
        return msg
        
    
class SUB_GS_USER_JOIN_RANDOM_LIST_SYN(PKT):
    main = codes_c2n['MAIN_GS_USER']
    sub = codes_c2n['SUB_GS_USER_JOIN_RANDOM_LIST_SYN']
    _t = 'MAIN_GS_USER|SUB_GS_USER_JOIN_RANDOM_LIST_SYN'
PKT.register(SUB_GS_USER_JOIN_RANDOM_LIST_SYN)

class SUB_GS_INFO(PKT):
    main = codes_c2n['MAIN_GS_FRAME']
    sub = codes_c2n['SUB_GS_INFO']
    _t = 'MAIN_GS_USER|SUB_GS_INFO'
    def body(self):
        return b'\x00'
PKT.register(SUB_GS_INFO)

class SUB_GS_OPTION(PKT):
    main = codes_c2n['MAIN_GS_FRAME']
    sub = codes_c2n['SUB_GS_OPTION']
    _t = 'MAIN_GS_FRAME|SUB_GS_OPTION'
    def decode_body(self, buf):
        self.cbGameStatus, self.cbAllowLookon = struct.unpack('<BB', buf)
PKT.register(SUB_GS_OPTION)

class SUB_S_START_SEND_CARD(PKT):
    main = codes_c2n['MAIN_GS_GAME']
    sub = codes_c2n['SUB_S_START_SEND_CARD']
    _t = 'MAIN_GS_GAME|SUB_S_START_SEND_CARD'
    def decode_body(self, data):
        cards = []
        for i in data[4:18]:
            if type(i) == int:
                cards.append(i)
            else:
                cards.append(ord(i))
        self.tiles = cards
        self.wSiceCount_1, self.wSiceCount_0, self.wBankerUser = struct.unpack('<BBH', data[:4])
        self.cbHuaCardData, self.lCellScore, self.StrategyNum = struct.unpack('<BIB', data[20:26])
PKT.register(SUB_S_START_SEND_CARD)

class SUB_S_SEND_CARD(PKT):
    main = codes_c2n['MAIN_GS_GAME']
    sub = codes_c2n['SUB_S_SEND_CARD']
    _t = 'MAIN_GS_GAME|SUB_S_SEND_CARD'
    def decode_body(self, data):
        self.user = struct.unpack('H', data[2:4])[0]
        self.tile = struct.unpack('B', data[:1])[0]
PKT.register(SUB_S_SEND_CARD)

class SUB_S_OUT_CARD(PKT):
    main = codes_c2n['MAIN_GS_GAME']
    sub = codes_c2n['SUB_S_OUT_CARD']
    _t = 'MAIN_GS_GAME|SUB_S_OUT_CARD'
    def decode_body(self, data):
        self.user, self.tile = struct.unpack('HB', data[:3])
PKT.register(SUB_S_OUT_CARD)

class SUB_S_OPERATE_RESULT(PKT):
    main = codes_c2n['MAIN_GS_GAME']
    sub = codes_c2n['SUB_S_OPERATE_RESULT']
    _t = 'MAIN_GS_GAME|SUB_S_OPERATE_RESULT'
    def decode_body(self, data):
        self.wOperateUser, self.wProvideUser, self.cbOperateCode, self.cbOperateCard = struct.unpack('hhbb', data[:6])
PKT.register(SUB_S_OPERATE_RESULT)

class SUB_S_OPERATE_NOTIFY(PKT):
    main = codes_c2n['MAIN_GS_GAME']
    sub = codes_c2n['SUB_S_OPERATE_NOTIFY']
    _t = 'MAIN_GS_GAME|SUB_S_OPERATE_NOTIFY'
    def decode_body(self, data):
        self.wResumeUser, self.wProvideUser, self.cbActionMask, self.cbActionCard, self.bIsQiangGangHu = struct.unpack('HHBBB', data)
PKT.register(SUB_S_OPERATE_NOTIFY)

class SUB_C_OUT_CARD(PKT):
    main = codes_c2n['MAIN_GS_GAME']
    sub = codes_c2n['SUB_C_OUT_CARD']
    _t = 'MAIN_GS_GAME|SUB_C_OUT_CARD'
    def __init__(self, tile = 0):
        self.tile = tile
    def decode_body(self, data):
        self.tile = struct.unpack('B', data)
    def body(self):
        return struct.pack('B', self.tile)
PKT.register(SUB_C_OUT_CARD)

class SUB_C_OPERATE_CARD(PKT):
    main = codes_c2n['MAIN_GS_GAME']
    sub = codes_c2n['SUB_C_OPERATE_CARD']
    _t = 'MAIN_GS_GAME|SUB_C_OPERATE_CARD'
    def decode_body(self, data):
        self.action, self.tile = struct.unpack('BB', data)
    def body(self):
        return struct.pack('BB', self.action, self.tile)
PKT.register(SUB_C_OPERATE_CARD)

class SUB_GS_USER_STATUS(PKT):
    main = codes_c2n['MAIN_GS_USER']
    sub = codes_c2n['SUB_GS_USER_STATUS']
    _t = 'MAIN_GS_USER|SUB_GS_USER_STATUS'
    def decode_body(self, buf):
        self.userID, self.tableID, self.chairID, self.netDelay, self.status = struct.unpack('<IHHHB', buf)
PKT.register(SUB_GS_USER_STATUS)

class SUB_GS_TABLE_STATUS(PKT):
    main = codes_c2n['MAIN_GS_STATUS']
    sub = codes_c2n['SUB_GS_TABLE_STATUS']
    _t = 'MAIN_GS_STATUS|SUB_GS_TABLE_STATUS'
    def decode_body(self, buf):
        self.tableID, self.havePassword, self.state, self.haveSitCondition, self.sitConditionValue = struct.unpack('<HBBBI', buf)
PKT.register(SUB_GS_TABLE_STATUS)

class SUB_GS_SYSMESSAGE(PKT):
    main = codes_c2n['MAIN_GS_SYSTEM']
    sub = codes_c2n['SUB_GS_SYSMESSAGE']
    _t = 'MAIN_GS_SYSTEM|SUB_GS_SYSMESSAGE'
    def decode_body(self, buf):
        self.type = struct.unpack('<H', buf[:2])[0]
        self.content, n = read_str(buf[2:])
PKT.register(SUB_GS_SYSMESSAGE)

class SUB_GS_LOGON_FAIL(PKT):
    main = codes_c2n['MAIN_GS_LOGON']
    sub = codes_c2n['SUB_GS_LOGON_FAIL']
    _t = 'MAIN_GS_LOGON|SUB_GS_LOGON_FAIL'
    def decode_body(self, buf):
        self.errorCode = struct.unpack('<i', buf[:4])[0]
        self.errorDesc, n = read_str(buf[4:])
PKT.register(SUB_GS_LOGON_FAIL)

class HEAT_BEAT(PKT):
    main = 0
    sub = 1
    _t = 'HEAT_BEAT|HEAT_BEAT'
    def decode_body(self, buf):
        self.raw= buf
    def body(self):
        return self.raw
PKT.register(HEAT_BEAT)

class SUB_GS_SERVER_INFO(PKT):
    main = codes_c2n['MAIN_GS_INFO']
    sub = codes_c2n['SUB_GS_SERVER_INFO']
    _t = 'MAIN_GS_INFO|SUB_GS_SERVER_INFO'
    def decode_body(self, buf):
        self.serverID, self.kindID, self.serverType, self.tableCount, self.chairCount = struct.unpack('<HHHHH', buf)
PKT.register(SUB_GS_SERVER_INFO)

class SUB_GS_USER_SCORE(PKT):
    main = codes_c2n['MAIN_GS_USER']
    sub = codes_c2n['SUB_GS_USER_SCORE']
    _t = 'MAIN_GS_USER|SUB_GS_USER_SCORE'
    def decode_body(self, buf):
        k = ('dwUserID', 'lGold', 'lScore', 'lWinCount', 'lLostCount', 'lDrawCount', 
          'lFleeCount', 'lExperience', 'lCharm', 'lGameCount', 'lGameCount_All', 'lWorkCount')
        info = dict(zip(k,struct.unpack('iiiiiiiiiiii',buf)))
        for i in info: self.__setattr__(i, info[i])
PKT.register(SUB_GS_USER_SCORE)

class SUB_S_GAME_END(PKT):
    main = codes_c2n['MAIN_GS_GAME']
    sub = codes_c2n['SUB_S_GAME_END']
    _t = 'MAIN_GS_GAME|SUB_S_GAME_END'
    def decode_body(self, buf):
        MAX_PLAYER = 4
        self.lGameTax, self.wProvideUser, self.cbProvideCard = struct.unpack('<ihb',buf[:7]); buf = buf[7:]
        self.dwChiHuKind = []
        tmp = self.dwChiHuKind 
        for i in range(MAX_PLAYER):
            j = struct.unpack('<i',buf[:4])[0]
            tmp.append(j)
            buf = buf[4:]
        self.dwChiDaHuKind = []
        tmp = self.dwChiDaHuKind 
        for i in range(MAX_PLAYER):
            j = struct.unpack('<i',buf[:4])[0]
            tmp.append(j)
            buf = buf[4:]
        self.dwChiHuRight = []
        tmp = self.dwChiHuRight 
        for i in range(MAX_PLAYER):
            j = struct.unpack('<i',buf[:4])[0]
            tmp.append(j)
            buf = buf[4:]
        self.cbHuaCount = struct.unpack('<b',buf[:1])[0]; buf = buf[1:]
        self.lWinTimes = []
        tmp = self.lWinTimes 
        for i in range(MAX_PLAYER):
            j = struct.unpack('<i',buf[:4])[0]
            tmp.append(j)
            buf = buf[4:]
        self.lGameScore = []
        tmp = self.lGameScore 
        for i in range(MAX_PLAYER):
            j = struct.unpack('<i',buf[:4])[0]
            tmp.append(j)
            buf = buf[4:]
        self.lGameGold = []
        tmp = self.lGameGold 
        for i in range(MAX_PLAYER):
            j = struct.unpack('<i',buf[:4])[0]
            tmp.append(j)
            buf = buf[4:]
        self.lExperience = []
        tmp = self.lExperience 
        for i in range(MAX_PLAYER):
            j = struct.unpack('<i',buf[:4])[0]
            tmp.append(j)
            buf = buf[4:]
        self.lTaiFei = struct.unpack('<i',buf[:4])[0]; buf = buf[4:]
        self.cbCardCount = []
        tmp = self.cbCardCount 
        for i in range(MAX_PLAYER):
            j = struct.unpack('<b',buf[:1])[0]
            tmp.append(j)
            buf = buf[1:]
        self.cbCardData = []
        for i in range(MAX_PLAYER):
            self.cbCardData.append([])
            tmp = self.cbCardData[i]
            for k in range(14):
                j = struct.unpack('<b',buf[:1])[0]; buf = buf[1:]
                tmp.append(j)
        self.bIsQiangGangHu, self.bIsLiuJu = struct.unpack('<??',buf[:2]); buf = buf[2:]
        self.cbHuPaiStyle = []
        for i in range(MAX_PLAYER):
            self.cbHuPaiStyle.append([])
            tmp = self.cbHuPaiStyle[i]
            for k in range(7):
                j = struct.unpack('<i',buf[:4])[0]; buf = buf[4:]
                tmp.append(j)
        self.PlayAS, self.bHuCard, self.bExtraWinTimes, self.wTianDiType = struct.unpack('<bbbH',buf[:5]); buf = buf[5:]
PKT.register(SUB_S_GAME_END)

class SUB_GS_USER_COME(PKT):
    main = codes_c2n['MAIN_GS_USER']
    sub = codes_c2n['SUB_GS_USER_COME']
    _t = 'MAIN_GS_USER|SUB_GS_USER_COME'
    def decode_body(self, data):
        k = ('wFaceID', 'cbGender', 'cbMember', 'lCharm', 'id', 'lBirthday_year', 'lBirthday_month', 
             'lBirthday_day', 'wTableID', 'wChairID', 'wNetDelay', 'cbUserStatus', 'dwUserRight', 
             'dwMasterRight', 'lGold', 'lScore', 'lWinCount', 'lLostCount', 'lDrawCount', 'lFleeCount', 
             'lExperience', 'onlineTime', 'lGameCount_Work', 'lLotteryCnt', 'lGameCount', 'lGameCount_All ', 'lNewMailCount')
        info = dict(zip(k,struct.unpack('<HbBIIIbbHHHbIIIIIIIIIIIIIII',data[2:2+85])))
        cursor = 2+85
        s, n = read_str(data[cursor:])
        info['szAccount'] = s
        cursor = cursor + n + 1
        s, n = read_str(data[cursor:])
        info['nickName'] = s
        cursor = cursor + n + 1
        s, n = read_str(data[cursor:])
        info['szBlog'] = s
        cursor = cursor + n + 1
        s, n = read_str(data[cursor:])
        info['Region0'] = s
        cursor = cursor + n + 1
        s, n = read_str(data[cursor:])
        info['Region1'] = s
        cursor = cursor + n + 1        
        self.info = info
PKT.register(SUB_GS_USER_COME)


class SUB_GS_LOGON_USERID(PKT):
    main = codes_c2n['MAIN_GS_LOGON']
    sub = codes_c2n['SUB_GS_LOGON_USERID']
    _t = 'MAIN_GS_LOGON|SUB_GS_LOGON_USERID'
    def __init__(self, id=0, pwd=''):
        self.id = id
        self.pwd = pwd
    def body(self):
        ret = b''
        ret += struct.pack('I', self.id)
        ret += b'\x00'
        ret += bytes(self.pwd, 'utf-8')
        ret += b'\x00'
        ret += struct.pack('I', 3)
        return ret
    def decode_body(self, buf):
        self.userID = struct.unpack('I', buf[:4])[0]
        self.password = read_str(buf[5:])
PKT.register(SUB_GS_LOGON_USERID)

class SUB_GS_USER_TASK_STATUS(PKT):
    main = codes_c2n['MAIN_GS_FRAME']
    sub = codes_c2n['SUB_GS_USER_TASK_STATUS']
    _t = 'MAIN_GS_FRAME|SUB_GS_USER_TASK_STATUS'
    def decode_body(self, buf):
        self.wTaskID, self.nCurrentVal, self.bIsFinished = struct.unpack('<Hi?', buf)
PKT.register(SUB_GS_USER_TASK_STATUS)

class SUB_GS_USER_TASK_INFO(PKT):
    main = codes_c2n['MAIN_GS_FRAME']
    sub = codes_c2n['SUB_GS_USER_TASK_INFO']
    _t = 'MAIN_GS_FRAME|SUB_GS_USER_TASK_INFO'
    def decode_body(self, buf):
        self.dwGroupID, n = struct.unpack('<IB', buf[:5])
        buf = buf[5:]
        self.task_infos = []
        for i in range(n):
            info = {}
            self.task_infos.append(info)
            block = buf[:115]; buf = buf[115:]
            (info['wTaskID'],) = struct.unpack('<H', block[:2])
            info['szTaskName'] = block[2:2+block[2:2+32].find(b'\x00')].decode('gbk')
            info['szTaskDesc'] = block[34:34+block[34:34+64].find(b'\x00')].decode('gbk')
            info['nTargetVal'], info['nCurrentVal'], info['bIsFinished'], info['eRewardsType'], info['RewardsNums'] = struct.unpack('<II?II',block[98:])
PKT.register(SUB_GS_USER_TASK_INFO)

