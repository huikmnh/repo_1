import sys

in_file = '/tmp/dem/ASTGTM2_N29E102_dem.tif'
in_file = sys.argv[1]

from PIL import Image
im = Image.open(in_file)

import numpy as np
ima = np.array(im)

rows, cols = im.size

aa = np.arange(0, rows*3, 3)
aa2 = np.arange(0, rows*3-2, 1)

from scipy.interpolate import RectBivariateSpline
interp_spline = RectBivariateSpline(aa, aa, ima)
new_grid = interp_spline(aa2, aa2)
new_rows, new_cols = new_grid.shape

import gdal
driver = gdal.GetDriverByName("GTiff")

in_f = gdal.Open(in_file)

outFileName = '/tmp/dem/a.tif'
outFileName = in_file[:-4]+'_30.tif'
outdata = driver.Create(outFileName, new_rows, new_cols, 1, gdal.GDT_UInt16)
# outband = outdata.GetRasterBand(1)

outdata.SetMetadata(in_f.GetMetadata())
outdata.SetProjection(in_f.GetProjectionRef())
t = list(in_f.GetGeoTransform())
t[1] /= 3
t[5] /= 3
outdata.SetGeoTransform(t)

in_f = None

outdata.GetRasterBand(1).WriteArray(np.rint(new_grid).astype(int))
outdata.FlushCache() ##saves to disk!!
outdata = None
