#!/usr/bin/env python
# coding: utf-8

###########################################################################################################
###########################################################################################################
import sys,os,traceback
import decimal, datetime, time
from sqlalchemy import (MetaData, Table, Column, Integer, Numeric, String,
                        DateTime, ForeignKey, Index, create_engine)
from sqlalchemy.ext.declarative import declarative_base

try:
    sheng_num = sys.argv[1]
except:
    sheng_num = '8'

engine = create_engine('mssql+pymssql://sjcq:KDcs@119!@172.21.%s.1:1433/ZDDW_GAW01'%sheng_num)

Base = declarative_base()
metadata = Base.metadata

es_host = '10.200.192.237:7200'
import elasticsearch, elasticsearch.helpers
es = elasticsearch.Elasticsearch(['10.200.192.49:7200'], http_auth=('elastic', 'kedacomezview'))

hjh_table_names = ['XFJD_DWXX', 'XFJD_JZ_MYJZ', 'XFJD_XTWH_CYDW', 'HJH_JZ_WXP', 'HJH_DWDA_DWJZGK', 'HJH_DWDA_ZZZYXFD', 
               'HJH_JZ_RZXX', 'HJH_FJXX', 'DM_XFJD_ZDDWSX', 'DM_XFJD_ZDDWXZ', 'DM_XFJD_XZQY', 
               'DM_XFJD_JZJG', 'DM_XFJD_JZWLB', 'DM_XFJD_JZYTFL', 'DM_XFJD_HJGL_FJLX', 'DM_XFJD_XFSSQK_JZ']

hjh_table_names = ['XFJD_DWXX', 'XFJD_JZ_MYJZ', 'XFJD_XTWH_CYDW', 'HJH_JZ_WXP', 'HJH_DWDA_DWJZGK', 'HJH_DWDA_ZZZYXFD', 
               'HJH_JZ_RZXX', 'HJH_FJXX', 'DM_XFJD_ZDDWSX', 'DM_XFJD_ZDDWXZ', 'HJH_DWDA_ZZZYXFDY', 'HJH_DWDA_XFRYZB',
               'DM_XFJD_JZJG', 'DM_XFJD_JZWLB', 'DM_XFJD_JZYTFL', 'DM_XFJD_HJGL_FJLX', 'DM_XFJD_XFSSQK_JZ']

xfjd_table_names = ['XFJD_DWXX', 'XFJD_JZ_MYJZ', 'XFJD_XTWH_CYDW', 'HJH_JZ_RZXX', 'XFJD_ZFGZDTTJ_SJJH', 'DM_XFJD_ZDDWSX', 
                    'DM_XFJD_ZDDWXZ', 'DM_XFJD_XZQY', 'DM_XFJD_JZJG', 'DM_XFJD_JZWLB', 'DM_XFJD_JZYTFL', 
                    'DM_XFJD_HJGL_FJLX', 'DM_XFJD_XFSSQK_JZ']

xfjd_table_names = ['XFJD_ZFGZDTTJ_SJJH', 'XFJD_XMXX', 'XFJD_DWXX']

import json
type_map = {
    str: {'type':'keyword'},
    int: {'type':'integer'},
    float: {'type':'float'},
    decimal.Decimal: {'type':'keyword'},
    datetime.datetime: {'type':'date', 'format': 'yyyy-MM-dd HH:mm:ss.SSS'}
}

def format_date(dt):
    return dt.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]

def sync_table_info(table_name, index_prefix='m_hjh_'):
    t = Table(table_name, metadata, autoload=True, autoload_with=engine)
    ic = elasticsearch.client.IndicesClient(es)
    mapping = {'sheng_num':{'type':'keyword'}}
    for c in t.columns:
#         print(c.name, c.type.python_type)
        mapping[c.name] = type_map[c.type.python_type]
    all_m = {'mappings':{t.name.lower():{'properties':mapping}}}
#     print('PUT m_hjh_%s'%t.name.lower())
#     print(json.dumps(all_m))
    ic.create(index='%s%s'%(index_prefix,t.name.lower()), body=all_m)
    
def bulk_actions(client, actions):
    try:
        succeeded, errors = elasticsearch.helpers.bulk(client=client, actions=actions)
        if succeeded == len(actions):
            return
    except:
        pass
    # if es inserts failed, we simplely exit and hope next time db sync operation will succeed
    os._exit(1)
    
def index_last_time(client, index_name, sheng_num, default='2000-01-01 00:00:00.000'):
    body = {"size":0,"query":{"term":{"sheng_num":{"value":sheng_num}}},"aggs":{"last_chgtime":{"max":{"field":"ChgTime"}}}}
    result = client.search(index=index_name, body=body)
    ret = default
    if 'value_as_string' in result['aggregations']['last_chgtime'] and result['aggregations']['last_chgtime']['value_as_string'] > ret:
        ret = result['aggregations']['last_chgtime']['value_as_string']
    return ret

# this function is suite for increamental data sync
def sync_table_data(table_name, index_name, sheng_num='8'):
    full_table_name = table_name
    table_name = table_name.split('.')[-1]
    try:
        last_update = es.get(index='m_last_chgtime', doc_type='chgtime', 
                             id='%s_%s'%(sheng_num,table_name.lower()))['_source']['ChgTime']
        sql = "select * from %s where ChgTime > '%s'"%(full_table_name, last_update)
    except:
        sql = "select * from %s"%full_table_name
    c = engine.raw_connection().cursor()
    print(sql)
    c.execute(sql)
    cols = len(c.description)
    req = []
    n = 0
    try:
        while True:
            rows = c.fetchmany(size=1000)
            if not rows:
                break
            for row in rows:
                r = {'sheng_num':sheng_num}
                for i in range(cols):
                    if row[i] == None:
                        continue
                    if c.description[i][0] == 'Row_Version':
                        continue
                    if c.description[i][1] == 4:
                        r[c.description[i][0]] = format_date(row[i])
                    else:
                        r[c.description[i][0]] = row[i]
                b = {'_index':index_name, '_type':table_name.lower(), '_id':'%s_%s'%(r['ID'],sheng_num), '_source':r}
                req.append(b)
                n += 1
                if n % 1000 == 0:
                    print('Got %d rows'%n)
            bulk_actions(es, req)
            req = []
    except:
        # maybe the databse operation failed
        traceback.print_exc()
        os._exit(2)
    if req:
        bulk_actions(es, req)
    print('Got %d rows'%n)
    body = {"size":0,"query":{"term":{"sheng_num":{"value":sheng_num}}},"aggs":{"last_update":{"max":{"field":"ChgTime"}}}}
    result = es.search(index=index_name, body=body)
    last_update = index_last_time(client=es, index_name=index_name, sheng_num=sheng_num, default="1970-01-01 00:00:00.000")
    es.index(index='m_last_chgtime', doc_type='chgtime', id='%s_%s'%(sheng_num,table_name.lower()), 
             body={"sheng_num":sheng_num,"table_name":table_name.lower(),"ChgTime":last_update})
    print('Done')
    
step = 100 # how many days for each step
TIME_BEGIN = '2000-01-01 00:00:00.000'
# this function is suite for initial data sync
def sync_table_data_2(table_name, index_name, sheng_num='8'):
    full_table_name = table_name
    table_name = table_name.split('.')[-1]
    now_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    ever_got_data = False
    end_time = ''
    while True:
        try:
            last_update = es.get(index='m_last_chgtime', doc_type='chgtime', 
                                 id='%s_%s'%(sheng_num,index_name))['_source']['ChgTime']
            if end_time == '':
                end_time = (datetime.datetime.strptime(last_update, "%Y-%m-%d %H:%M:%S.%f") 
                           + datetime.timedelta(days=step)).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
            else:
                end_time = (datetime.datetime.strptime(end_time, "%Y-%m-%d %H:%M:%S.%f") 
                           + datetime.timedelta(days=step)).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
            sql = "select * from %s where ChgTime > '%s' and ChgTime <= '%s'"%(full_table_name, last_update, end_time)
        except:
            if end_time == '':
                end_time = TIME_BEGIN
            else:
                end_time = (datetime.datetime.strptime(end_time, "%Y-%m-%d %H:%M:%S.%f") 
                           + datetime.timedelta(days=step)).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
            sql = "select * from %s where ChgTime <= '%s' or ChgTime is null"%(full_table_name, end_time)
        c = engine.raw_connection().cursor()
        print(sheng_num, sql)
        c.execute(sql)
        cols = len(c.description)
        req = []
        n = 0
        try:
            while True:
                rows = c.fetchmany(size=1000)
                if not rows:
                    break
                for row in rows:
                    r = {'sheng_num':sheng_num}
                    for i in range(cols):
                        if row[i] == None:
                            continue
                        if c.description[i][0] == 'Row_Version':
                            continue
                        if c.description[i][1] == 4:
                            r[c.description[i][0]] = format_date(row[i])
                        else:
                            r[c.description[i][0]] = row[i]
                    b = {'_index':index_name, '_type':table_name.lower(), '_id':'%s_%s'%(r['ID'],sheng_num), '_source':r}
                    req.append(b)
                    n += 1
                    ever_got_data = True
                    if n % 1000 == 0:
                        print('Got %d rows'%n)
                bulk_actions(es, req)
                req = []
        except:
            # maybe the databse operation failed
            traceback.print_exc()
            os._exit(2)
        if req:
            bulk_actions(es, req)
        print('Got %d rows'%n)
        if n:
            time.sleep(1)
        if n:
            last_update = index_last_time(client=es, index_name=index_name, sheng_num=sheng_num, default=TIME_BEGIN)
            es.index(index='m_last_chgtime', doc_type='chgtime', id='%s_%s'%(sheng_num,index_name), 
                 body={"sheng_num":sheng_num,"table_name":table_name.lower(),"ChgTime":last_update})
        if end_time > now_time:
            break
    print('Done')

# for i in hjh_table_names:
#     sync_table_info(i, 'm_hjh_')

def sync_all_table_data(tables, sheng_num):
    for i in tables:
        print('Syncing table [%s]'%i)
        sync_table_data_2(i, 'm_hjh_%s'%i.lower(), sheng_num)

def sync_all_xfjd_table_data(tables, sheng_num):
    for i in tables:
        print('Syncing table [%s]'%i)
        sync_table_data_2('XFJDGL01.dbo.'+i, 'm_xfjd_%s'%i.lower(), sheng_num)        
        
sync_all_table_data(hjh_table_names, sheng_num)
sync_all_xfjd_table_data(xfjd_table_names, sheng_num)
