import elasticsearch, elasticsearch.helpers
import traceback

es = elasticsearch.Elasticsearch(['10.200.192.49:7200'], http_auth=('elastic', 'kedacomezview'))
#oracle_url = 'oracle+cx_oracle://ezview:ezview@10.2.196.58:2521/orcl'
oracle_url = 'oracle+cx_oracle://ezview:ezview@10.200.192.217:2521/orcl'

class D(object):
    def __init__(self, d):
        self.d = d
    def __getattr__(self, name):
        try:
            return self.d[name]
        except:
            return None

###########################################################################################################
###########################################################################################################
# 获取字典项

# 消防单位信息
def oracle_dwbh():
    import os
    os.environ['NLS_LANG'] = 'SIMPLIFIED CHINESE_CHINA.ZHS32GB18030'
    DM_XFDW_32 = {}
    DM_XFDW_8 = {}

    from datetime import datetime
    from sqlalchemy import (MetaData, Table, Column, Integer, Numeric, String, create_engine)
    from sqlalchemy.ext.declarative import declarative_base
    from sqlalchemy.orm import sessionmaker

    engine = create_engine(oracle_url)

    c = engine.raw_connection().cursor()
    c.execute('select DWBH, JGNBID, DWMC, LSGX, SZDXZQH from mid_db_yth.a_fire_xfdw order by jgnbid')
    rows = c.fetchall()
    for i in range(7):
        in_rows = len(DM_XFDW_32)
        for DWBH, JGNBID, DWMC, LSGX, SZDXZQH in rows:
            info = {}
            info['DWBH'] = DWBH
            info['JGNBID'] = JGNBID
            info['DWMC'] = DWMC
            info['SZDXZQH'] = SZDXZQH
            if DWBH == LSGX:
                info['CHAIN'] = '1.'+DWBH
            else:
                try:
                    info['CHAIN'] = DM_XFDW_32[LSGX]['CHAIN']+'.'+DWBH
                except:
                    continue
            DM_XFDW_32[DWBH] = info
            DM_XFDW_8[JGNBID] = info
        if in_rows == len(DM_XFDW_32):
            break
    return DM_XFDW_32, DM_XFDW_8

# 行政区域
def oracle_xzbm():
    ret = {}
    import os
    os.environ['NLS_LANG'] = 'SIMPLIFIED CHINESE_CHINA.ZHS32GB18030'

    from datetime import datetime
    from sqlalchemy import (MetaData, Table, Column, Integer, Numeric, String, create_engine)
    from sqlalchemy.ext.declarative import declarative_base
    from sqlalchemy.orm import sessionmaker

    engine = create_engine(oracle_url)

    Base = declarative_base()
    metadata = Base.metadata

    class BQjXzqy(Base):
        __tablename__ = 'b_qj_xzqy'

        xzmc = Column(String(128), nullable=False)
        xzjb = Column(Numeric(3, 0, asdecimal=False), nullable=False)
        xzqh = Column(String(16))
        xznbbm = Column(String(256))
        xzjc = Column(String(26))
        xssx = Column(String(2))
        sfky = Column(String(8))
        qypy = Column(String(1024))
        ylzd1 = Column(String(56))
        ylzd2 = Column(String(128))
        ylzd3 = Column(String(256))
        zfjg = Column(String(64))
        xmin = Column(String(64))
        ymin = Column(String(64))
        xmax = Column(String(64))
        ymax = Column(String(64))
        xzfbm = Column(String(64))
        xzbm = Column(String(64), primary_key=True)
        
    class XzbhMap(Base):
        __tablename__ = 'xzbhmap'

        jxzbh = Column(String(16), primary_key=True)
        xxzbh = Column(String(16))
    
    Session = sessionmaker(bind=engine)
    session = Session()
    al = session.query(BQjXzqy)
    for i in al:
        ret[i.xzbm] = {'ID':i.xzbm, 'VALUE':i.xzmc, 'CHAIN':i.xznbbm}
    al = session.query(XzbhMap)
    for i in al:
        try:
            ret[i.jxzbh] = ret[i.xxzbh]
        except:
#             print(i.xxzbh)
            pass
    return ret