#!/usr/bin/env python
# coding: utf-8


###########################################################################################################
###########################################################################################################
import sys
from datetime import datetime, timedelta
from sqlalchemy import (MetaData, Table, Column, Integer, Numeric, String, Float, SmallInteger, text,
                        DateTime, ForeignKey, Index, create_engine)
from sqlalchemy.ext.declarative import declarative_base
import elasticsearch, elasticsearch.helpers
import traceback

es_host = '10.200.192.49:9200'
db_host = '172.21.8.1'
try:
    db_host = sys.argv[1]
except:
    pass

engine = create_engine('mssql+pymssql://XFDB:YESQUMCWIQVB@%s:1433/XFJDGL01'%db_host)
es = elasticsearch.Elasticsearch([es_host], http_auth=('elastic', 'kedacomezview'))

#  oracle_url = 'oracle+cx_oracle://ezview:ezview@10.2.196.58:2521/orcl'
oracle_url = 'oracle+cx_oracle://ezview:ezview@10.200.192.217:2521/orcl'

# engine = create_engine('mssql+pymssql://sjcq:KDcs@119!@10.2.61.4:4433/XFJDGL01')
# es_host = '192.168.6.202:7200'

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

Session = sessionmaker(bind=engine)

session = Session()

Base = declarative_base()
metadata = Base.metadata



# In[34]:


###########################################################################################################
###########################################################################################################
# 表定义

# 动态统计 数据交换
class XFJDZFGZDTTJSJJH(Base):
    __tablename__ = 'XFJD_ZFGZDTTJ_SJJH'
    __table_args__ = (
        Index('IND_XFJD_ZFGZDTTJ_SJJH_SJRQ_DWID_PCSHZ', 'SFPCSHZ', 'DWID', 'SJRQ'),
    )

    ID = Column(String(32, 'Chinese_PRC_CI_AS'), primary_key=True, server_default=text("([dbo].[GetUUID](newid()))"))
    DWID = Column(String(20, 'Chinese_PRC_CI_AS'), nullable=False, index=True)
    SFBHXS = Column(String(1, 'Chinese_PRC_CI_AS'), server_default=text("((1))"))
    SFBHPCS = Column(String(1, 'Chinese_PRC_CI_AS'), server_default=text("((0))"))
    SFPCSHZ = Column(String(1, 'Chinese_PRC_CI_AS'), server_default=text("((0))"))
    SFHJ = Column(String(1, 'Chinese_PRC_CI_AS'), server_default=text("((0))"))
    SFHHBS = Column(String(1, 'Chinese_PRC_CI_AS'), server_default=text("((0))"))
    SJRQ = Column(DateTime, index=True)
    MBSJJHDWID = Column(String(20, 'Chinese_PRC_CI_AS'))
    Col_101 = Column(Integer)  
    Col_102 = Column(Integer)  # 1 检查单位（总数）
    Col_103 = Column(Integer)  # 2 发现火灾隐患或违法行为（起）
    Col_104 = Column(Integer)  # 6 下发临时查封决定书（份） 
    Col_105 = Column(Integer)  # 4 下发责令改正通知书（份）
    Col_106 = Column(Integer)  
    Col_107 = Column(Integer)
    Col_108 = Column(Integer)
    Col_109 = Column(Integer)
    Col_110 = Column(Integer)
    Col_111 = Column(Integer)  # 3 督促整改火灾隐患或违法行为
    Col_112 = Column(Integer)  
    Col_113 = Column(Integer)
    Col_114 = Column(Integer)
    Col_115 = Column(Float(53))
    Col_116 = Column(Integer)
    Col_117 = Column(Integer)
    Col_118 = Column(Integer)
    Col_121 = Column(Integer)
    Col_122 = Column(Integer)  # 1：人员密集场所
    Col_123 = Column(Integer)  # 2：高层公共建筑
    Col_124 = Column(Integer)  # 3：高层居住建筑
    Col_125 = Column(Integer)  # 4：地下建筑
    Col_126 = Column(Integer)  # 5：在建工程施工工地
    Col_127 = Column(Integer)
    Col_128 = Column(Float(53))
    Col_201 = Column(Integer)  # 7：消防控制室
    Col_202 = Column(Integer)  # 8：排查建筑、单位、场所总数
    Col_203 = Column(Integer)
    Col_204 = Column(Integer)
    Col_205 = Column(Float(53))
    Col_301 = Column(Integer)
    Col_302 = Column(Integer)
    Col_303 = Column(Integer)
    Col_304 = Column(Integer)
    Col_305 = Column(Integer)
    Col_306 = Column(Integer)
    Col_307 = Column(Integer)
    Col_308 = Column(Integer)
    Col_309 = Column(Integer)
    Col_310 = Column(Float(53))
    Col_321 = Column(Float(53))
    Col_322 = Column(Integer)
    Col_323 = Column(Float(53))
    Col_401 = Column(Integer)  # 6：节能综合工程施工现场
    Col_402 = Column(Integer)
    Col_403 = Column(Integer)
    Col_404 = Column(Integer)
    Col_405 = Column(Integer)
    Col_406 = Column(Integer)
    Col_407 = Column(Integer)
    Col_408 = Column(Integer)
    Col_409 = Column(Integer)
    Col_410 = Column(Float(53))
    Col_501 = Column(Integer)
    Col_502 = Column(Integer)
    Col_503 = Column(Integer)
    Col_504 = Column(Integer)
    Col_505 = Column(Integer)
    Col_506 = Column(Integer)
    Col_507 = Column(Integer)
    Col_508 = Column(Integer)
    Col_509 = Column(Integer)
    Col_510 = Column(Float(53))
    Col_601 = Column(Integer)
    Col_602 = Column(Integer)
    Col_603 = Column(Integer)
    Col_604 = Column(Integer)
    Col_605 = Column(Float(53))
    Col_701 = Column(Integer)
    Col_702 = Column(Integer)
    Col_703 = Column(Integer)
    Col_704 = Column(Integer)
    Col_705 = Column(Float(53))  # 9 罚款（元）
    Col_706 = Column(Integer)  # 8 责令“三停”单位（总数）
    Col_707 = Column(Integer)  # 10 拘留（人）
    Col_708 = Column(Integer)
    Col_709 = Column(Integer)
    Col_710 = Column(Float(53))
    Col_711 = Column(Float(53))
    Col_712 = Column(Integer)  # 5 下发行政处罚决定书（份）
    Col_713 = Column(Integer)
    Col_714 = Column(Integer)
    Col_715 = Column(Float(53))
    Col_731 = Column(Float(53))
    Col_732 = Column(Integer)
    Col_733 = Column(Integer)
    Col_734 = Column(Integer)
    Col_735 = Column(Integer)
    Col_736 = Column(Float(53))
    Col_737 = Column(Integer)
    Col_738 = Column(Integer)
    Col_739 = Column(Float(53))
    Col_751 = Column(Integer)
    Col_752 = Column(Integer)
    Col_753 = Column(Integer)
    Col_754 = Column(Integer)
    Col_755 = Column(Integer)
    Col_756 = Column(Integer)
    Col_757 = Column(Integer)
    Col_758 = Column(Integer)
    Col_759 = Column(Float(53))
    Col_771 = Column(Integer)
    Col_772 = Column(Integer)
    Col_773 = Column(Integer)
    Col_774 = Column(Integer)
    Col_775 = Column(Integer)
    Col_776 = Column(Integer)
    Col_777 = Column(Integer)  # 7 下发行政强制决定书（份）
    Col_778 = Column(Integer)
    Col_779 = Column(Float(53))
    Col_791 = Column(Integer)
    Col_792 = Column(Integer)
    Col_793 = Column(Integer)
    Col_794 = Column(Integer)
    Col_795 = Column(Float(53))
    Col_801 = Column(Integer)
    Col_802 = Column(Integer)
    Col_803 = Column(Float(53))
    Col_804 = Column(Integer)
    Col_805 = Column(Float(53))
    SFSGSB = Column(String(1, 'Chinese_PRC_CI_AS'), server_default=text("((0))"))
    Acc = Column(String(20, 'Chinese_PRC_CI_AS'))
    AccName = Column(String(50, 'Chinese_PRC_CI_AS'))
    InTime = Column(DateTime)
    ChgAcc = Column(String(20, 'Chinese_PRC_CI_AS'))
    ChgAccName = Column(String(50, 'Chinese_PRC_CI_AS'))
    ChgTime = Column(DateTime, index=True)
    Ip = Column(String(30, 'Chinese_PRC_CI_AS'))
    Deleted = Column(String(1, 'Chinese_PRC_CI_AS'), nullable=False, server_default=text("('0')"))
    SpareFiled1 = Column(String(100, 'Chinese_PRC_CI_AS'))
    SpareFiled2 = Column(String(200, 'Chinese_PRC_CI_AS'))
    SpareFiled3 = Column(DateTime)
    JLZT = Column(SmallInteger, index=True)
    SJTJSJ = Column(DateTime)
    SJJSSJ = Column(DateTime)
    CZMS = Column(String(1500, 'Chinese_PRC_CI_AS'))
    Row_Version = Column(DateTime, nullable=False)
    
# 字典项 行政区域
class DMXFJDXZQY(Base):
    __tablename__ = 'DM_XFJD_XZQY'

    ID = Column(String(32, 'Chinese_PRC_CI_AS'), primary_key=True)
    CodeID = Column(String(20, 'Chinese_PRC_CI_AS'), nullable=False)
    CodeName = Column(String(1000, 'Chinese_PRC_CI_AS'))
    SJZDDMZ = Column(String(20, 'Chinese_PRC_CI_AS'))
    SJZDDMMPY = Column(String(200, 'Chinese_PRC_CI_AS'))
    DMBID = Column(String(32, 'Chinese_PRC_CI_AS'))
    Levels = Column(String(1, 'Chinese_PRC_CI_AS'))
    UpperCodeID = Column(String(20, 'Chinese_PRC_CI_AS'))
    Type = Column(String(1, 'Chinese_PRC_CI_AS'))
    Remark = Column(String(1000, 'Chinese_PRC_CI_AS'))
    IsShow = Column(String(1, 'Chinese_PRC_CI_AS'), nullable=False)
    OrderNum = Column(SmallInteger)
    Acc = Column(String(20, 'Chinese_PRC_CI_AS'))
    AccName = Column(String(50, 'Chinese_PRC_CI_AS'))
    InTime = Column(DateTime)
    InIP = Column(String(30, 'Chinese_PRC_CI_AS'))
    ChgAcc = Column(String(20, 'Chinese_PRC_CI_AS'))
    ChgAccName = Column(String(50, 'Chinese_PRC_CI_AS'))
    ChgTime = Column(DateTime)
    Ip = Column(String(30, 'Chinese_PRC_CI_AS'))
    Deleted = Column(String(1, 'Chinese_PRC_CI_AS'), nullable=False)
    SpareFiled1 = Column(String(100, 'Chinese_PRC_CI_AS'))
    SpareFiled2 = Column(String(200, 'Chinese_PRC_CI_AS'))
    SpareFiled3 = Column(DateTime)






###########################################################################################################
###########################################################################################################
# 获取字典项

# 行政区域
#al = session.query(DMXFJDXZQY.CodeID, DMXFJDXZQY.UpperCodeID, DMXFJDXZQY.CodeName).order_by(DMXFJDXZQY.CodeID).all()
#DM_XZQY = {}
#DM_XZQY['1'] = {'ID':'1', 'VALUE':'根', 'CHAIN':'1'}
#for i in al:
#    upper_id = i.UpperCodeID
#    if not upper_id: upper_id = '1'
#    DM_XZQY[i.CodeID] = {'ID':i.CodeID, 'VALUE':i.CodeName, 'CHAIN':(DM_XZQY[upper_id]['CHAIN']+'.'+i.CodeID)}


DM_XFDW_32 = {}
DM_XFDW_8 = {}
def oracle_dwbh():
    import os
    os.environ['NLS_LANG'] = 'SIMPLIFIED CHINESE_CHINA.ZHS32GB18030'

    from datetime import datetime
    from sqlalchemy import (MetaData, Table, Column, Integer, Numeric, String, create_engine)
    from sqlalchemy.ext.declarative import declarative_base
    from sqlalchemy.orm import sessionmaker

#    engine = create_engine('oracle+cx_oracle://ezview:ezview@10.200.192.236:2521/orcl')
    engine = create_engine(oracle_url)

    c = engine.raw_connection().cursor()
    c.execute('select DWBH, JGNBID, DWMC, LSGX, SZDXZQH from mid_db_yth.a_fire_xfdw order by jgnbid')
    rows = c.fetchall()
    for i in range(7):
        in_rows = len(DM_XFDW_32)
        for DWBH, JGNBID, DWMC, LSGX, SZDXZQH in rows:
            info = {}
            info['DWBH'] = DWBH
            info['JGNBID'] = JGNBID
            info['DWMC'] = DWMC
            info['SZDXZQH'] = SZDXZQH
            if DWBH == LSGX:
                info['CHAIN'] = '1.'+DWBH
            else:
                try:
                    info['CHAIN'] = DM_XFDW_32[LSGX]['CHAIN']+'.'+DWBH
                except:
                    continue
            DM_XFDW_32[DWBH] = info
            DM_XFDW_8[JGNBID] = info
        if in_rows == len(DM_XFDW_32):
            break
oracle_dwbh()

# 行政区域
def oracle_xzbm():
    ret = {}
    import os
    os.environ['NLS_LANG'] = 'SIMPLIFIED CHINESE_CHINA.ZHS32GB18030'

    from datetime import datetime
    from sqlalchemy import (MetaData, Table, Column, Integer, Numeric, String, create_engine)
    from sqlalchemy.ext.declarative import declarative_base
    from sqlalchemy.orm import sessionmaker

    engine = create_engine(oracle_url)

    Base = declarative_base()
    metadata = Base.metadata

    class BQjXzqy(Base):
        __tablename__ = 'b_qj_xzqy'

        xzmc = Column(String(128), nullable=False)
        xzjb = Column(Numeric(3, 0, asdecimal=False), nullable=False)
        xzqh = Column(String(16))
        xznbbm = Column(String(256))
        xzjc = Column(String(26))
        xssx = Column(String(2))
        sfky = Column(String(8))
        qypy = Column(String(1024))
        ylzd1 = Column(String(56))
        ylzd2 = Column(String(128))
        ylzd3 = Column(String(256))
        zfjg = Column(String(64))
        xmin = Column(String(64))
        ymin = Column(String(64))
        xmax = Column(String(64))
        ymax = Column(String(64))
        xzfbm = Column(String(64))
        xzbm = Column(String(64), primary_key=True)
        
    class XzbhMap(Base):
        __tablename__ = 'xzbhmap'

        jxzbh = Column(String(16), primary_key=True)
        xxzbh = Column(String(16))
    
    Session = sessionmaker(bind=engine)
    session = Session()
    al = session.query(BQjXzqy)
    for i in al:
        ret[i.xzbm] = {'ID':i.xzbm, 'VALUE':i.xzmc, 'CHAIN':i.xznbbm}
    al = session.query(XzbhMap)
    for i in al:
        try:
            ret[i.jxzbh] = ret[i.xxzbh]
        except:
#             print(i.xxzbh)
            pass
    return ret
DM_XZQY = oracle_xzbm()


###########################################################################################################
###########################################################################################################
# do the work
yy_host = engine.url.host

def fetch_zftj():
    q = session.query(XFJDZFGZDTTJSJJH.ID, XFJDZFGZDTTJSJJH.SJRQ, XFJDZFGZDTTJSJJH.SFPCSHZ, XFJDZFGZDTTJSJJH,
                     XFJDZFGZDTTJSJJH.Col_122, XFJDZFGZDTTJSJJH.Col_123, XFJDZFGZDTTJSJJH.Col_124, XFJDZFGZDTTJSJJH.Col_125,
                     XFJDZFGZDTTJSJJH.Col_126, XFJDZFGZDTTJSJJH.Col_401, XFJDZFGZDTTJSJJH.Col_201, XFJDZFGZDTTJSJJH.Col_202,
                     XFJDZFGZDTTJSJJH.Col_102, XFJDZFGZDTTJSJJH.Col_103, XFJDZFGZDTTJSJJH.Col_111, XFJDZFGZDTTJSJJH.Col_105,
                     XFJDZFGZDTTJSJJH.Col_712, XFJDZFGZDTTJSJJH.Col_104, XFJDZFGZDTTJSJJH.Col_777, XFJDZFGZDTTJSJJH.Col_706,
                     XFJDZFGZDTTJSJJH.Col_705, XFJDZFGZDTTJSJJH.Col_707,
                     XFJDZFGZDTTJSJJH.DWID, XFJDZFGZDTTJSJJH.AccName, XFJDZFGZDTTJSJJH.InTime, XFJDZFGZDTTJSJJH.ChgAccName, 
                     XFJDZFGZDTTJSJJH.ChgTime).filter(XFJDZFGZDTTJSJJH.SFHJ == '1', 
                                                      XFJDZFGZDTTJSJJH.SJRQ >= (datetime.today()-timedelta(days=30))
                                                     ).yield_per(2000).all()
    req = []
    for a in q:
        zftj = {}
        zftj['TJBH'] = a.ID
        zftj['TJRQ'] = a.SJRQ.strftime('%Y-%m-%d')
        zftj['TJLY'] = a.SFPCSHZ
        jcdx = []
        jcdx.append({'DXLX':'1', 'TJSL':a.Col_122})
        jcdx.append({'DXLX':'2', 'TJSL':a.Col_123})
        jcdx.append({'DXLX':'3', 'TJSL':a.Col_124})
        jcdx.append({'DXLX':'4', 'TJSL':a.Col_125})
        jcdx.append({'DXLX':'5', 'TJSL':a.Col_126})
        jcdx.append({'DXLX':'6', 'TJSL':a.Col_401})
        jcdx.append({'DXLX':'7', 'TJSL':a.Col_201})
        jcdx.append({'DXLX':'8', 'TJSL':a.Col_202})
        zftj['JCDX'] = jcdx
        jcjg = []
        jcjg.append({'JGLX':'1', 'TJSL':a.Col_102})
        jcjg.append({'JGLX':'2', 'TJSL':a.Col_103})
        jcjg.append({'JGLX':'3', 'TJSL':a.Col_111})
        jcjg.append({'JGLX':'4', 'TJSL':a.Col_105})
        jcjg.append({'JGLX':'5', 'TJSL':a.Col_712})
        jcjg.append({'JGLX':'6', 'TJSL':a.Col_104})
        jcjg.append({'JGLX':'7', 'TJSL':a.Col_777})
        jcjg.append({'JGLX':'8', 'TJSL':a.Col_706})
        jcjg.append({'JGLX':'9', 'TJSL':int(a.Col_705)})
        jcjg.append({'JGLX':'10', 'TJSL':a.Col_707})
        zftj['JCJG'] = jcjg
#         xfgxdw = session.query(XFJDXTWHCYDW).filter(XFJDXTWHCYDW.DWID == a.DWID).first()
#         zftj['SZDXFJG'] = {'XFJGBH':a.DWID, 'XFJGNBBM':a.DWID, 'XFJGMC':DM_XFDW[a.DWID]}
        try:
#            zftj['SZDXFJG'] = {'XFJGBH':a.DWID, 'XFJGNBBM':a.DWID, 'XFJGMC':DM_XFDW2DWMC[a.DWID]}
            zftj['SZDXFJG'] = {'XFJGBH':DM_XFDW_8[a.DWID]['DWBH'], 'XFJGNBBM':DM_XFDW_8[a.DWID]['CHAIN'], 
                               'XFJGMC':DM_XFDW_8[a.DWID]['DWMC']}
        except:
            continue
        try:
            xzqy = DM_XFDW_8[a.DWID]['SZDXZQH']
        except:
            xzqy = '110000'
        try:
            zftj['SZDXZQH'] = {'XZQHBH':xzqy, 'XZQHMC':DM_XZQY[xzqy]['VALUE'], 'XZQHNBBM':DM_XZQY[xzqy]['CHAIN']}
            zftj['SZDXZQH'] = {'XZQHBH':xzqy, 'XZQHMC':DM_XZQY[xzqy]['VALUE'], 'XZQHNBBM':DM_XZQY[xzqy]['CHAIN']}
        except:
    #         traceback.print_exc()
            zftj['SZDXZQH'] = {'XZQHBH':xzqy, 'XZQHMC':'UNKNOWN', 'XZQHNBBM':'1.999999'}
        #jzxx['JSNR']
        zftj['JLZT'] = '1'
        zftj['RKRY'] = a.AccName
        zftj['RKSJ'] = a.InTime.strftime('%Y-%m-%d %H:%M:%S')
        zftj['GXRY'] = a.ChgAccName
        if a.ChgTime:
            zftj['GXSJ'] = a.ChgTime.strftime('%Y-%m-%d %H:%M:%S')
        else:
            zftj['DWCLSJ'] = datetime.now().strftime('%Y-%m-%d')
    #     print(zftj)
    #     print('--------------------------------')
        b = {'_index':'a_fire_zftj', '_type':'zftj', '_id':zftj['TJBH'], '_source':zftj}
    #     es.index(index='v_fire_zftj', doc_type='zftj',id=zftj['TJBH'], body=zftj)
        req.append(b)
        if len(req) == 1000:
            elasticsearch.helpers.bulk(client=es, actions=req)
            req = []
    if req:
        elasticsearch.helpers.bulk(client=es, actions=req)

fetch_zftj()


