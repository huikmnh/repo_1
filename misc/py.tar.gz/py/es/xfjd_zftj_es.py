#!/usr/bin/env python
# coding: utf-8

from common import *

DM_XFDW_32, DM_XFDW_8 = oracle_dwbh()
DM_XZQY = oracle_xzbm()


from datetime import datetime, timedelta

def fetch_zftj():
    from_time = datetime.today()-timedelta(days=30)
    body = {"query":{"range":{"SJRQ":{"gte":from_time.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]}}}}
    al = elasticsearch.helpers.scan(client=es, index='m_xfjd_xfjd_zfgzdttj_sjjh', size=8000, query=body)
    req = []
    for j in al:
        a = D(j['_source'])
        zftj = {}
        zftj['TJBH'] = a.ID
        zftj['TJRQ'] = a.SJRQ[:10]
        zftj['TJLY'] = a.SFPCSHZ
        jcdx = []
        jcdx.append({'DXLX':'1', 'TJSL':a.Col_122})
        jcdx.append({'DXLX':'2', 'TJSL':a.Col_123})
        jcdx.append({'DXLX':'3', 'TJSL':a.Col_124})
        jcdx.append({'DXLX':'4', 'TJSL':a.Col_125})
        jcdx.append({'DXLX':'5', 'TJSL':a.Col_126})
        jcdx.append({'DXLX':'6', 'TJSL':a.Col_401})
        jcdx.append({'DXLX':'7', 'TJSL':a.Col_201})
        jcdx.append({'DXLX':'8', 'TJSL':a.Col_202})
        zftj['JCDX'] = jcdx
        jcjg = []
        jcjg.append({'JGLX':'1', 'TJSL':a.Col_102})
        jcjg.append({'JGLX':'2', 'TJSL':a.Col_103})
        jcjg.append({'JGLX':'3', 'TJSL':a.Col_111})
        jcjg.append({'JGLX':'4', 'TJSL':a.Col_105})
        jcjg.append({'JGLX':'5', 'TJSL':a.Col_712})
        jcjg.append({'JGLX':'6', 'TJSL':a.Col_104})
        jcjg.append({'JGLX':'7', 'TJSL':a.Col_777})
        jcjg.append({'JGLX':'8', 'TJSL':a.Col_706})
        jcjg.append({'JGLX':'9', 'TJSL':int(a.Col_705)})
        jcjg.append({'JGLX':'10', 'TJSL':a.Col_707})
        zftj['JCJG'] = jcjg
        try:
            zftj['SZDXFJG'] = {'XFJGBH':DM_XFDW_8[a.DWID]['DWBH'], 'XFJGNBBM':DM_XFDW_8[a.DWID]['CHAIN'], 
                               'XFJGMC':DM_XFDW_8[a.DWID]['DWMC']}
        except:
            continue
        try:
            xzqy = DM_XFDW_8[a.DWID]['SZDXZQH']
        except:
            xzqy = '110000'
        try:
            zftj['SZDXZQH'] = {'XZQHBH':xzqy, 'XZQHMC':DM_XZQY[xzqy]['VALUE'], 'XZQHNBBM':DM_XZQY[xzqy]['CHAIN']}
            zftj['SZDXZQH'] = {'XZQHBH':xzqy, 'XZQHMC':DM_XZQY[xzqy]['VALUE'], 'XZQHNBBM':DM_XZQY[xzqy]['CHAIN']}
        except:
    #         traceback.print_exc()
            zftj['SZDXZQH'] = {'XZQHBH':xzqy, 'XZQHMC':'UNKNOWN', 'XZQHNBBM':'1.999999'}
        zftj['JLZT'] = '1'
        zftj['RKRY'] = a.AccName
        zftj['RKSJ'] = a.InTime[:19]
        zftj['GXRY'] = a.ChgAccName
        if a.ChgTime:
            zftj['GXSJ'] = a.ChgTime[:19]
        else:
            zftj['GXSJ'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        b = {'_index':'a_fire_zftj', '_type':'zftj', '_id':zftj['TJBH'], '_source':zftj}
        req.append(b)
        if len(req) == 1000:
            elasticsearch.helpers.bulk(client=es, actions=req)
            req = []
    if req:
        elasticsearch.helpers.bulk(client=es, actions=req)
        
fetch_zftj()