#!/usr/bin/env python
# coding: utf-8

# In[1]:


net_num = ['196', '8', '24', '94', '100', '78', '106', '14', '32', '227', '124', '72', '88', '112', '130', '136', 
           '48', '56', '142', '40', '148', '185', '154', '64', '160', '166', '188', '172', '178', '192', '20']
#net_num = [i for i in net_num if i not in ['40', '78', '142', '20']]


# In[2]:


import concurrent.futures
import os

def do_all(max_threads = 10):
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_threads) as executor:
        for i in net_num:
            executor.submit(os.system, '/root/py/xfjd_db_sync.py %s' % i)
        executor.shutdown()
    print('Done')


# In[4]:


#get_ipython().magic('time do_all()')
do_all()
