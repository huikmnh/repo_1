import random,sys


while sys.stdin.readline():
  print(random.randint(0,10), ' + ', random.randint(0,10))


