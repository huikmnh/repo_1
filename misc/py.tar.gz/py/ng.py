
import threading
LOCK = threading.Lock()

from http.server import HTTPServer, BaseHTTPRequestHandler

from io import BytesIO

import json

search_works = []

class SimpleHTTPRequestHandler(BaseHTTPRequestHandler):
    
    def do_GET(self):
        ou = {"id":55, "name":"egg"}
        ob = json.dumps(ou)
        with LOCK:
#             print(dir(self))
#             print(self.path)
            self.send_response(200)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            if self.path == '/test/hello':
                self.wfile.write(ob.encode('utf-8'))
            elif self.path == '/device/list':
                ou = [
                    {'id':'11111', 'status':'ON'},
                    {'id':'22222', 'status':'OFF'},
                    {'id':'44444', 'status':'ON'}
                ]
                ob = json.dumps(ou)
                self.wfile.write(ob.encode('utf-8'))

    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        body = self.rfile.read(content_length)
        self.send_response(200)
        self.end_headers()
        response = BytesIO()
        response.write(b'This is POST request. ')
        response.write(b'Received: ')
        response.write(body)
        self.wfile.write(response.getvalue())


httpd = HTTPServer(('0.0.0.0', 8000), SimpleHTTPRequestHandler)
httpd.serve_forever()