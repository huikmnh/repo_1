import struct, inspect
import hexdump, zlib
import traceback

def decode_1(body):
    key = bytearray(b'\xf9\xa3\xff\xf8')
    ret = bytearray(body)
    ## 0F8FFA3F9h
    for i in range(len(body)):
        ret[i] = ret[i] ^ key[i%4]
    return bytes(ret)

def decode_2(body):
    compressed_len = struct.unpack('i', body[8:12])[0]
#     key = bytearray(b'\xf9\xa3\xff\xf8')
    key = struct.unpack('i', b'\xf9\xa3\xff\xf8')[0]
#     key = bytearray(struct.pack('i', 0xf8ffa3f9 - compressed_len))
    key = bytearray(struct.pack('i', key - compressed_len))
    ret = bytearray(body)
    ## 0F8FFA3F9h
    for i in range(len(body)):
        ret[i] = ret[i] ^ key[i%4]
    for i in (8, 9, 10, 11):
        ret[i] = ret[i] ^ key[i%4]
    return bytes(ret)

def decode_block_header(body):
    origin_len, compressed_len = struct.unpack('ii', body[8:16])
    key = struct.unpack('i', b'\xf9\xa3\xff\xf8')[0]
    compressed_len = compressed_len ^ key - origin_len
    key = struct.pack('i', key - origin_len)
    return key, compressed_len, origin_len

def decode_block_bak(body, key):
    ret = bytearray(body)
    key = bytearray(key)
#     end = ((len(body) - 4) >> 2) << 2  # last 4 bytes never encode
#     end_2 = (len(body) >> 4) << 4
    end = ((len(body) ) >> 2) << 2
    if end_2 > end:
        end = end_2
    for i in range(end):
        ret[i] = ret[i] ^ key[i%4]
    return ret

def decode_block_bak_2(body, key):
    ret = bytearray(body)
    key = bytearray(key)
    a2 = len(body) + 16
    v13 = a2 - 4;
    v15 = (a2 - 21) >> 2;
    v16 = v15 + 1;
    v17 = ((v15 - 3) >> 2) + 1;
    v18 = 4 * v17;
    v23 = 16 * v17 + 16;
    if v16 == v18:
        end = 16*v17
    else:
        end = 16*v17 + 4
        if v23 + 4 < v13:
            end += 4
            if v23 + 8 < v13:
                end += 4
    for i in range(end):
        ret[i] = ret[i] ^ key[i%4]
    return ret

def decode_block(body, key):
    ret = bytearray(body)
    key = bytearray(key)
    end = (len(body)-1) >> 2 << 2
    for i in range(end):
        ret[i] = ret[i] ^ key[i%4]
    return ret

level_shift_right = {19:9, 17:11, 15:12, 12:16, 10:16, 9:18, 7:20, 5:22}
level_shift_left = {19:7, 17:5, 15:4, 12:0, 10:0, 9:0, 7:0, 5:0}

def xy_2_idx(x, y, level):
    shift = level_shift_right[level]
    x = x >> shift
    y = y >> shift
    c3 = (x & 0x7) | ((y & 0x7) << 3)
    c2 = ((x>>3) & 0x7) | (((y>>3) & 0x7) << 3)
    c1 = ((x>>6) & 0x7) | (((y>>6) & 0x7) << 3)
    shift_c0 = level_shift_left[level]
    x = x >> 9
    y = y >> 9
    c0 = x | ( y << shift_c0 )
    return c0, c1, c2, c3

def idx_2_xy(idx, level):
    c0, c1, c2, c3 = idx
    t = 2**level_shift_left[level] - 1
    n = c0 & t
    n = (c1 & 0x7) | (n << 3)
    n = (c2 & 0x7) | (n << 3)
    n = (c3 & 0x7) | (n << 3)
    n = n << level_shift_right[level]
    x = n
    c0 = c0 >> level_shift_left[level]
    c1 = c1 >> 3
    c2 = c2 >> 3
    c3 = c3 >> 3
    n = c0 & t
    n = (c1 & 0x7) | (n << 3)
    n = (c2 & 0x7) | (n << 3)
    n = (c3 & 0x7) | (n << 3)
    n = n << level_shift_right[level]
    y = n
    return x, y

powers = {(1<<i):1 for i in range(17)}

def get_layer_by_id(block, id):
    for layer in block.layer:
        if layer.layerId == id:
            return layer

trick = [0]
        

class VMap():
    def __init__(self, filename='/tmp/shanghai_289.dat'):
        self.dz = zlib.decompressobj()
        content = open(filename, 'rb').read()
        self.content = content
        c = content
        self.size_all = len(c)
        s = struct.unpack('i', c[0x20:0x24])[0]
        self.size_h0 = 0x20 + 4 + s
        h1 = c[self.size_h0:self.size_h0+0x100]
        h1 = decode_1(h1)
        p = self.size_h0+0x100
        self.level_count = struct.unpack('i', h1[0x50:0x54])[0]
        self.size_trees = struct.unpack('i', h1[0x9C:0x9C+4])[0]
        levels = []
        self.levels = levels
        self.size_h1 = 0x100
        self.size_h2 = 0x40 * self.level_count
        h2 = c[p:p+self.level_count*0x40]
        h2 = decode_1(h2)
        self.levels_info = {}
        for i in range(self.level_count):
            levels.append(struct.unpack('h', h1[0x58+8*i:0x58+2+8*i])[0])
            root = struct.unpack('i', h2[0x40*i+0x10:0x40*i+0x10+4])[0]
            self.levels_info[levels[i]] = {}
            self.levels_info[levels[i]]['root'] = root
            s00, s01, s10, s11, s20, s21, s30, s31 = struct.unpack('BBBBBBBB', h2[0x40*i:0x40*i+8])
            assert s00 == s01 and s10 == s11 and s20 == s21 and s30 == s31
            self.levels_info[levels[i]]['idx_block_size'] = s00*s01, s10*s11, s20*s21, s30*s31 # idx item size not byte size
        for i in range(self.level_count-1):
            self.levels_info[levels[i]]['end'] = self.levels_info[levels[i+1]]['root']
        self.levels_info[levels[-1]]['end'] = self.size_h1+self.size_h2+self.size_trees
        h = self.size_h0 + self.size_h1 + self.size_h2
        self.idx_part = h1+h2+decode_1(c[h:h+self.size_trees-4])+c[h+self.size_trees-4:h+self.size_trees]
        
    def get_block_pos(self, loc):
#         header_offset = 0x2e ## 0x2f
        header = self.content[loc+self.size_h0:loc+self.size_h0+0x10]
        key, compressed_len, origin_len = decode_block_header(header)
        block = self.content[loc+self.size_h0+0x10:loc+self.size_h0+0x10+compressed_len]
        block = decode_block(block, key)
        dz = zlib.decompressobj()
        block = dz.decompress(block)[:origin_len]
        return block           

    def get_block_xy(self, xy, level):
        c0, c1, c2, c3 = xy_2_idx(xy[0], xy[1], level)
        n0 = self.levels_info[level]['root']
        p = n0 + c0*4
        n1 = struct.unpack('i', self.idx_part[p:p+4])[0]
        p = n1 + c1*4
        n2 = struct.unpack('i', self.idx_part[p:p+4])[0]
        p = n2 + c2*4
        n2 = struct.unpack('i', self.idx_part[p:p+4])[0]
        p = n2 + c3*4
        n3 = struct.unpack('i', self.idx_part[p:p+4])[0]
        header = self.content[n3+0x2f:n3+0x2f+0x10]
#         return header
        key, compressed_len, origin_len = decode_block_header(header)
        print(key, compressed_len, origin_len)
        block = self.content[n3+0x2f+0x10:n3+0x2f+0x10+compressed_len]
#         return block
        block = decode_block(block, key)
        assert block[:2] == b'\x78\x9C'
#         assert False
        dz = zlib.decompressobj()
        block = dz.decompress(block)[:origin_len]
        return block
        
    def __repr__(self):
        atts = {}
        for i in dir(self):
#             print(i)
            if i[0] == '_' or i in ('contentaa', ) :
                continue
            att = self.__getattribute__(i)
            if type(att) == bytes:
                continue
            if inspect.ismethod(att):
                continue
            atts[i] = att
#         print(type(atts))
#         print(atts.keys())
#         return 'gogogo'
        return '%s ==> %s'%('hello',atts.__repr__())
    
    def walk_idx_tree_bak(self, level):
        s0 = self.levels_info[level]['root']
        e0 = self.levels_info[level]['end']
        p0 = s0
        size_0 = 0
        size_1 = 0
        size_2 = 0
        size_3 = 0
        while True:
            v = struct.unpack('i', self.idx_part[p0:p0+4])[0]
            if v > 0:
                size_0 = v - s0
                assert size_0 in powers
                print('size_0', size_0)
                break
            p0 += 4
        e0 = s0 + size_0
        v0 = []
        for i in range(size_0>>2):
            v = struct.unpack('i', self.idx_part[s0+i*4:s0+i*4+4])[0]
            if v > 0: v0.append(i)
        if size_1 == 0 and len(v0) > 1:
            ii_0, ii_1 = s0 + v0[0]*4, s0 + v0[1]*4
            size_1 = struct.unpack('i', self.idx_part[ii_1:ii_1+4])[0] - struct.unpack('i', self.idx_part[ii_0:ii_0+4])[0]
            assert size_1 in powers
            print('size_1', size_1)
        for i_1 in v0:
            s1 = struct.unpack('i', self.idx_part[s0+i_1*4:s0+i_1*4+4])[0]
            p = s1
            if size_1 == 0:
                while True:
                    v = struct.unpack('i', self.idx_part[p:p+4])[0]
                    if v > 0:
                        size_1 = v - s1
                        assert size_1 in powers
                        print('size_1', size_1)
                        break
                    p += 4
            e1 = s1 + size_1
            v1 = []
            for i in range(size_1>>2):
                v = struct.unpack('i', self.idx_part[s1+i*4:s1+i*4+4])[0]
                if v > 0: v1.append(i)
            if size_2 ==0 and len(v1) > 1:
                ii_0, ii_1 = s1 + v1[0]*4, s1 + v1[1]*4
                size_2 = struct.unpack('i', self.idx_part[ii_1:ii_1+4])[0] - struct.unpack('i', self.idx_part[ii_0:ii_0+4])[0]
                assert size_2 in powers
                print('size_2', size_2)
            for i_2 in v1:
                s2 = struct.unpack('i', self.idx_part[s1+i_2*4:s1+i_2*4+4])[0]
                p = s2
                if size_2 == 0:
                    while True:
                        v = struct.unpack('i', self.idx_part[p:p+4])[0]
                        if v > 0:
                            size_2 = v - s2
                            assert size_2 in powers
                            print('size_2', size_2)
                            break
                        p += 4
                e2 = s2 + size_2
                v2 = []
                for i in range(size_2>>2):
                    v = struct.unpack('i', self.idx_part[s2+i*4:s2+i*4+4])[0]
                    if v > 0: v2.append(i)
                if size_3 == 0 and len(v2) > 1:
                    ii_0, ii_1 = s2 + v2[0]*4, s2 + v2[1]*4
                    size_3 = struct.unpack('i', self.idx_part[ii_1:ii_1+4])[0] - struct.unpack('i', self.idx_part[ii_0:ii_0+4])[0]
                    assert size_3 in powers
                    print('size_3', size_3)
                for i_3 in v2:
                    s3 = struct.unpack('i', self.idx_part[s2+i_3*4:s2+i_3*4+4])[0]
                    p = s3
                    if size_3 == 0:
                        while True:
                            v = struct.unpack('i', self.idx_part[p:p+4])[0]
                            if v > 0:
                                if v > self.levels_info[level]['end']:
                                    size_3 = self.levels_info[level]['end'] - s3
                                else:
                                    size_3 = v - s3
                                assert size_3 in powers
                                print('size_3', size_3)
                                break
                            p += 4
                    e3 = s3 + size_3
                    for i in range(size_3>>2):
                        v = struct.unpack('i', self.idx_part[s3+i*4:s3+i*4+4])[0]
                        if v > 0:
#                             print('###########> ', hex(i_1), i_1, i_2, i_3, i)
                            pass
                            if i_2 == 0x2b and i_3 == 0x16 and i == 0x3a:
                                print('###########> ', hex(i_1), i_1, i_2, i_3, i, hex(v))
            
    def walk_idx_tree(self, level, f = None):
        s0 = self.levels_info[level]['root']
        size_0, size_1, size_2, size_3 = self.levels_info[level]['idx_block_size']
        n = 0
        for i_0 in range(size_0):
            c0, = struct.unpack('i', self.idx_part[s0+i_0*4:s0+i_0*4+4])
            if c0 > 0:
                for i_1 in range(size_1):
                    c1, = struct.unpack('i', self.idx_part[c0+i_1*4:c0+i_1*4+4])
                    if c1 > 0:
                        for i_2 in range(size_2):
                            c2, = struct.unpack('i', self.idx_part[c1+i_2*4:c1+i_2*4+4])
                            if c2 >0:
                                for i_3 in range(size_3):
                                    c3, = struct.unpack('i', self.idx_part[c2+i_3*4:c2+i_3*4+4]); trick[0] = c3
                                    if c3 > 0:
                                        if n >= 500000:
                                            return
                                        else:
                                            pass
                                        try:
                                            block = self.get_block_pos(c3)
                                            bl.Clear()
                                            bl.ParseFromString(block)
                                            if f:
                                                xy = idx_2_xy((i_0, i_1, i_2, i_3), 19)
                                                f(bl, xy)
                                            layer = get_layer_by_id(bl, 8)
                                            if layer:
#                                                 print('---------------------------', c3)
                                                n += 1
    #                                         print(get_layer_by_id(bl, 8))
#                                                 print(layer)
                                        except:
                                            traceback.print_exc()
                                            print('Oops', c3, i_0, i_1, i_2, i_3)
#                                         print('###########> ', hex(i_0), i_0, i_1, i_2, i_3)
                                        if i_1 == 0x2b and i_2 == 0x16 and i_3 == 0x3a:
                                            print('###########> ', hex(i_0), i_0, i_1, i_2, i_3)
            
import map_pb2
bl = map_pb2.Block()

def every_2_bits(raw):
    ret = []
    for n in raw:
        ret.append(n>>6)
        ret.append( (n>>4)&3 )
        ret.append( (n>>2)&3 )
        ret.append( n&3 )
    return ret

def decode_ints_with_bitmap(raw, bitmap):
    ret = []
    bitmap = every_2_bits(bitmap)
    n = 0
    for i in bitmap:
        item = 0
        for j in range(i+1):
            h = raw[n]
            item = item + (h<<(8*j))
            n += 1
        ret.append(item)
        if n == len(raw):
            break
    return ret

def lastbit_sign(a):
    if a&1:
        return (a>>1)*-1
    else:
        return a>>1
    
def pg(a, base_x=0, base_y=0, scale=1):
    x0, y0, a = a[0], a[1], a[2:]
    ret = [(x0,y0)]
    while a:
        dx, dy, a = a[0], a[1], a[2:]
        ret.append((ret[-1][0]+dx, ret[-1][1]+dy))
#     if ret[-1][0] - x0 < 0.1 and ret[-1][1] - y0 < 0.1:
#         ret[-1] = x0, y0
    ret = [(base_x+x/10, base_y+y/10) for (x, y) in ret]
    return ret

import json

out_f = None

def f1(block, base_xy):
    x, y = base_xy
#     x, y = 0, 0
    layer = get_layer_by_id(bl, 8)
    if layer:
        for body in layer.body:
            for b2 in body.b2:
                val = decode_ints_with_bitmap(b2.bo.data, b2.bo.mask)
                val = [lastbit_sign(i) for i in val]
                val = pg(val, x, y, 10)
                if out_f:
#                     out_f.write('%d %d %d'% (trick[0], base_xy[0], base_xy[1]))
                    out_f.write(json.dumps({'outline':val, 'height':b2.bo.height}))
                    out_f.write('\n')
                else:
                    print(json.dumps(val))
            
def f_poi(block, base_xy):
    x, y = base_xy
    layer = get_layer_by_id(bl, 3)
    if layer:
        for body in layer.body:
            for b2 in body.b2:
                if out_f:
                    out_f_poi.write(json.dumps({'tag':body.tag, 'poi':b2.poi.poi, 'location':(x+b2.poi.x/100, y+b2.poi.y/100)}, ensure_ascii=False))
                    out_f_poi.write('\n')
            
            
m1 = VMap('/tmp/aomentebiexingzheng_2911.dat')
out_f = open('/tmp/2911.json', 'w')
out_f_poi = open('/tmp/2911_poi.json', 'w')


m1.walk_idx_tree(19, f1)
m1.walk_idx_tree(19, f_poi)

out_f.close()
out_f_poi.close()